-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Apr 05, 2023 at 11:53 AM
-- Wersja serwera: 5.7.41
-- Wersja PHP: 8.1.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogs`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  `stars` int(2) DEFAULT '0',
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `promoted` tinyint(1) DEFAULT NULL,
  `fileName` varchar(128) DEFAULT NULL,
  `fileId` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `author`, `created`, `description`, `stars`, `image`, `category`, `promoted`, `fileName`, `fileId`) VALUES
(1, 'test Title', 'test Author', '2023-03-11 18:03:47', 'lorem ipsum', 17, 'https://fastly.picsum.photos/id/981/200/300.jpg?hmac=H3LDLzNJiLGQYdx_Q7g_Us-x8VxR-aK5TglLyGlQHDk', 'sport', 1, NULL, NULL),
(2, 'Title1', 'Stachu', '2023-03-12 15:06:49', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 9, 'https://fastly.picsum.photos/id/881/200/300.jpg?hmac=OaIsS2cuxcnUpCVdxcFoc8JwfJgzWEv2Z9F_qEN9tHU', 'sport', NULL, NULL, NULL),
(3, 'Title2', 'Adam', '2023-03-12 15:06:48', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 22, 'https://fastly.picsum.photos/id/483/200/300.jpg?hmac=D_dBiQY-_Hb5jICLp91Jagw6tJ3CeHNGJOkAJznIfCw', 'politics', 1, NULL, NULL),
(4, 'Title3', 'Adam', '2023-03-12 15:06:47', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 37, 'https://fastly.picsum.photos/id/881/200/300.jpg?hmac=OaIsS2cuxcnUpCVdxcFoc8JwfJgzWEv2Z9F_qEN9tHU', 'war', NULL, NULL, NULL),
(5, 'Title4', 'John', '2023-03-12 15:06:46', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 13, 'https://fastly.picsum.photos/id/124/200/300.jpg?hmac=nYVSpzq7GaVkXrTk1whDiPbZdNRgtpJJXZJjvmUtFp0', 'war', NULL, NULL, NULL),
(6, 'Title5', 'Edwin', '2023-03-12 15:06:45', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 9, 'https://fastly.picsum.photos/id/886/200/300.jpg?hmac=QjMnUZ6TpLONThQRlITZiIa_Q9-iB4QQRI9FcpsbBvM', 'news', NULL, NULL, NULL),
(7, 'Title6', 'John', '2023-03-12 15:06:44', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 49, 'https://fastly.picsum.photos/id/715/200/300.jpg?hmac=jMgGkNrRGTz5pgw27YMTCyozftm33Rw2fPKQU2FypW4', 'celebrities', NULL, NULL, NULL),
(8, 'Title7', 'Mike', '2023-03-12 15:06:43', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 8, 'https://fastly.picsum.photos/id/739/200/300.jpg?hmac=xApsFbHx511SUVG612QiltrATotVTYu3Q4wfvGyYC1g', 'news', NULL, NULL, NULL),
(9, 'Title8', 'Stachu', '2023-03-12 15:06:42', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 17, 'https://fastly.picsum.photos/id/198/200/300.jpg?hmac=Jnk3eRWYnOUbfVsjK23Mj6kSpEIk-yivwNwNUPZCgiA', 'war', NULL, NULL, NULL),
(10, 'Title9', 'Mike', '2023-03-12 15:06:41', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 7, 'https://fastly.picsum.photos/id/875/200/300.jpg?hmac=9NSoqXHP89pGlq4Sz3OgGxjx5c91YHJkcIOBFgNJ8xA', 'sport', NULL, NULL, NULL),
(11, 'Title10', 'Stachu', '2023-03-12 15:06:40', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus itaque vitae, mollitia voluptate odio facere aspernatur tenetur labore culpa. Libero cum nulla reprehenderit aliquid maiores accusantium repellendus omnis ducimus distinctio similique! Reprehenderit, autem? Quos quod deserunt sint perspiciatis saepe omnis nemo inventore voluptatibus sapiente, laudantium qui nesciunt error animi porro, nihil alias quibusdam adipisci libero neque molestiae fugiat est molestias nisi. Aliquid nesciunt quasi, adipisci odio ea similique, error cumque optio eum esse ipsum quae libero pariatur! Iusto amet harum ad nemo dolores reprehenderit eligendi ea natus sint, nulla at ipsum cumque illum molestias non minus iure veritatis, error excepturi obcaecati inventore. Est explicabo ipsum iure animi? Iusto quibusdam tenetur blanditiis labore animi voluptatum voluptates nihil repudiandae odit enim provident dolores error, quia, sapiente itaque dolor nobis. Repellat, aspernatur reiciendis reprehenderit totam repudiandae quos ex, deserunt fugiat exercitationem odio esse consectetur odit nulla laudantium maiores? Rerum et ab magnam inventore?', 10, 'https://fastly.picsum.photos/id/509/200/300.jpg?hmac=Y2Mtq5PEipyaFNlDH01CoNhW9to1T8GCuTf6yUSH-TY', 'sport', NULL, NULL, NULL),
(22, NULL, NULL, '2023-03-25 18:58:20', NULL, NULL, NULL, 'science', NULL, NULL, NULL),
(25, NULL, NULL, '2023-03-25 19:01:25', NULL, NULL, NULL, 'travel', NULL, NULL, NULL),
(47, 'star2', 'star2', '2023-03-27 05:44:52', '', 2, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'sport', NULL, NULL, NULL),
(48, 'star3', 'Karol', '2023-03-27 05:47:26', '', 2, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'sport', NULL, NULL, NULL),
(51, 'saving in DB', 'Tom', '2023-03-28 16:06:21', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel risus id ligula tempus efficitur. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis varius tempor arcu a convallis. Vivamus et fermentum leo. Proin mollis lorem sit amet venenatis condimentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer facilisis urna eu ornare imperdiet. Aliquam a porta nibh. Phasellus luctus tristique luctus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam erat volutpat. Etiam aliquam aliquam diam at finibus. Sed non sapien lacus. In semper.', 2, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'politics', 1, 'face.jpg', '6423107d780424.82157160.jpg'),
(56, 'File Test2', 'Karol', '2023-03-29 09:38:26', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris purus nibh, porttitor eget leo vitae, dictum consectetur urna. Vivamus in cursus risus. Nullam id tincidunt libero, eu fringilla purus. Proin id sodales arcu. Ut eu ligula non justo hendrerit efficitur. Donec varius, ex ut sodales pretium, magna metus volutpat orci, sed maximus neque lacus vel eros. Aenean in leo nec est porta iaculis eget in sem. Quisque varius ligula eget lacus vestibulum, sit amet luctus leo semper. Aliquam efficitur ante ut posuere tincidunt. Nunc in leo erat. Aliquam sit amet libero feugiat, scelerisque erat et, sollicitudin mi. Proin lacinia auctor est, id auctor purus euismod vitae.\r\n\r\nQuisque vestibulum a orci vel suscipit. Suspendisse porta, nunc ac venenatis hendrerit, lorem dui euismod ipsum, at pellentesque felis justo vel diam. Proin pellentesque, tortor vitae scelerisque porttitor, eros turpis imperdiet est, a pretium augue dui vel eros. Donec id egestas tortor. Aliquam vulputate libero ac accumsan pretium. Mauris est felis, iaculis id enim posuere, placerat tristique elit. Ut cursus pellentesque ante, a laoreet orci bibendum volutpat. Etiam eget erat laoreet, finibus sem in, lobortis turpis. In varius risus eu lacinia hendrerit. Aliquam lobortis, nunc sit amet dignissim fringilla, nisi odio auctor mi, non venenatis magna eros nec nulla. Cras id vulputate est, ut varius odio. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec ultrices pretium lacus non pulvinar. Praesent sodales consectetur metus, sit amet congue eros.\r\n\r\nDonec egestas quam ut dui iaculis euismod. Aenean vitae leo diam. Curabitur eleifend, dolor vehicula facilisis vehicula, nibh urna laoreet diam, id congue erat ligula id quam. Cras at viverra lorem. Ut ex sapien, malesuada in sapien vitae, condimentum pretium arcu. Aenean id eleifend risus, sed rutrum augue. Vestibulum interdum accumsan libero, sed eleifend justo tempor eget. Nullam tellus justo, porta eu dui a, euismod ultricies quam. Duis tortor velit, interdum eu feugiat sed, tempus sed felis. Quisque sed metus eu eros porttitor ultrices.\r\n\r\nCras iaculis facilisis consectetur. Suspendisse nulla ipsum, facilisis non tincidunt in, sagittis id urna. Nulla ut tortor sed nisl accumsan imperdiet et ac nulla. Proin molestie sapien tortor, sit amet fringilla augue pulvinar id. Aliquam quis porta elit. Mauris eleifend ligula vitae nibh porta sollicitudin. Maecenas ut urna neque.    ', 1, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'sport', NULL, NULL, NULL),
(58, 'File test 8', 'Peter', '2023-03-29 12:37:52', '   ', 3, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'war', 1, NULL, NULL),
(61, 'Prepare STMT', 'Max', '2023-04-04 06:08:45', '', 0, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'celebrities', 1, '', NULL),
(62, 'Prepare STMT', 'Max', '2023-04-04 06:11:18', '', 0, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'celebrities', 1, 'TEST.pdf', '642bbf8669c477.53406753.pdf'),
(63, 'Test 1500100900', 'Alf', '2023-04-04 06:38:57', 'dasda', 0, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'celebrities', 1, '', NULL),
(70, 'test1', 'test1', '2023-04-04 07:06:35', '  tests   ', 0, 'https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY', 'celebrities', 1, '', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stars`
--

CREATE TABLE `stars` (
  `user_id` int(1) NOT NULL,
  `post_id` int(1) NOT NULL,
  `voted` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stars`
--

INSERT INTO `stars` (`user_id`, `post_id`, `voted`) VALUES
(1, 58, 1),
(1, 1, 1),
(35, 58, 1),
(35, 48, 1),
(35, 56, 1),
(35, 1, 1),
(35, 4, 1),
(35, 50, 1),
(35, 50, 1),
(35, 3, 1),
(35, 3, 1),
(35, 3, 1),
(35, 11, 1),
(35, 6, 1),
(35, 7, 1),
(35, 7, 1),
(35, 7, 1),
(35, 7, 1),
(35, 51, 1),
(35, 8, 1),
(35, 9, 1),
(77, 51, 1),
(73, 58, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `created`, `admin`) VALUES
(1, 'Stachu2', 'car14@wp.pl', '$2y$10$zLB8HkB23iNpaVP0BUy7heDlex6QL/CWRuTTsShv1K/Xlc7TzXOoO', '2023-03-17 08:37:05', 1),
(2, 'Stachu', 'car1@wp.pl', '$2y$10$CR3eX7tb5TSEF8ipxcCUY.TWggquqxLfCvKUQcQrpmhJmstWcizYC', '2023-03-17 08:41:53', NULL),
(3, 'Stachu', 'car2@wp.pl', '$2y$10$3OQrB3cWPtF2I9dd0gm/8OrJatJKPzOwTgsARAGuDgi37vIwVzjIq', '2023-03-18 06:54:39', NULL),
(31, 'Stachu', 'car3@wp.pl', '$2y$10$DwBUsfFRH1nTSuNBdKdUaOKAKdBLabG7KhdgEVYqWm/rCGwmXEY2m', '2023-03-18 08:03:45', NULL),
(33, 'Stachu', 'car5@wp.pl', '$2y$10$lop0OdKbzxqFih9/AT6W3OOMmxOtImw7voRd2.HcN7PiXza2hf3Yq', '2023-03-18 08:07:54', NULL),
(35, 'Stachu', 'car6@wp.pl', '$2y$10$wounCaclwJ4IlBOH6aoxbu1nKQhXA219b3aKI9m.gKP9veM.K/kFO', '2023-03-18 08:14:32', 1),
(36, 'Stachu', 'car7@wp.pl', '$2y$10$kCZxx5/9e48vq.OY7CoSD.LvT1NZMt7N/acnKx8JeUVNcQK1kIQ9W', '2023-03-18 08:15:39', NULL),
(37, 'Stachu', 'car8@wp.pl', '$2y$10$CBrG9f9aSS5xEfh5TIPlse8wJASzwfedLwAtXGAGm4NYTf2yHw5BW', '2023-03-18 08:17:29', NULL),
(40, 'Stachu', 'car9@wp.pl', '$2y$10$ZXsm5Z1LL4I.Tz3o8wSRg./mqOFT8JouZLtWch1wefjc9XeD8z9aW', '2023-03-18 20:00:22', NULL),
(43, 'Stachu', 'car12@wp.pl', '$2y$10$fuAKegbOuRLDBABSaMHcceIkXTp9XGLOT8XZyE6W1Td7J2M7OsObq', '2023-03-18 21:52:15', NULL),
(44, 'Stachu', 'car13@wp.pl', '$2y$10$EPf/Sef6..niLH2hFgQmYuWUSXZxYyoAn3CPl0OJpxvH2RZGc6gfy', '2023-03-18 22:12:52', NULL),
(50, 'Stachu', 'car19@wp.pl', '$2y$10$36RvRTNBi9ajhV.QcMJF9On1xXU6yiR6FhlzWa20h1qgiVJpNUXOm', '2023-03-19 19:36:03', NULL),
(51, 'Stachu', 'car21@wp.pl', '$2y$10$bQc0YyljOnl4AQ/YUsYJX.Hx11zxRQAUdx85JNTM20P5.6JzwVNmu', '2023-03-19 21:15:25', NULL),
(53, 'Stachu', 'car22@wp.pl', '$2y$10$P9HZj1rzsqvUDPuSxKMgzOQ4ZzFUXypn1nulm4J12TRqMBJx./XNe', '2023-03-19 21:16:11', NULL),
(54, 'Stachu', 'car24@wp.pl', '$2y$10$eNX6xxsMcBGZyjVex5onFO372szatgDT0oW8iPVc3Z9jhKXd9nC0a', '2023-03-19 21:36:09', NULL),
(55, 'Adam', 'car33@wp.pl', '$2y$10$4pDL5CttSgb7UdFdFnYJbeEWgCjv1MjDotr/surTTQoEd5UPIVGji', '2023-03-20 18:42:32', 1),
(56, 'Dawid', 'car54@wp.pl', '$2y$10$eX8d8hGGgTdZe2n6FMO2D.Esl/VZYCns24zLpSomXKoltUIVFvmQ.', '2023-03-20 18:43:40', NULL),
(57, 'Roberto', 'lewandowski@wp.pl', '$2y$10$zIzAX8POT99G4.lFXh9F8eQ1x6WB8jPiG569ty0hJT3Zx2n14sIou', '2023-03-20 18:46:22', 1),
(72, 'Rosie Simpson', 'admin3@admin.pl', '$2y$10$RtgFR0Vot3x13NLFzfXW/u7JUW91x/BfzC38f3KW10SWTqW8xGI4m', '2023-03-27 07:48:03', NULL),
(73, 'Admin', 'admin@admin.pl', '$2y$10$LWWTEdJfgPDNLOEl32CkmeNDT0BZL1hfAyb.diV9/FsTGG5fxxx.K', '2023-03-27 07:49:07', 1),
(74, 'Rosie Simpson', 'Peter@admin.pl', '$2y$10$ZFflpqSBtd0r87VNwrOPAOBy9RyYPLdiaGynvhRpyr/2ZEFKSM3de', '2023-03-27 17:22:24', NULL),
(75, 'Wayne', 'example@example.pl', '$2y$10$HglaUDnz3WJW7mI4x92SL.qSRDND16icC.l/kJtqHjc.Up.rslcDm', '2023-03-29 09:41:50', NULL),
(76, 'joanna', 'asia@gmail.com', '$2y$10$.SSbw94b5JfygxmqXzMhauk6XSHGTvHZtUtVj7oxKXaVOgkRcEmm.', '2023-03-29 09:45:19', NULL),
(77, 'Rosie Simpson', 'car34@wp.pl', '$2y$10$5P88gLNgpWWe7dtY7JQkw.QC8Jjo.vEvTiFOZPnS0nFABlhkkluwu', '2023-04-01 10:48:34', NULL),
(78, 'Rosie Simpson22', 'car64@wp.pl', '$2y$10$/hKAPhi9z/O7RpsL3aGAwOgUHWlJnBhWQpsNS/1n5kPI.UOi3axM2', '2023-04-01 11:03:53', 1);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `stars`
--
ALTER TABLE `stars`
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
