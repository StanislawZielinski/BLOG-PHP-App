<?php
declare(strict_types=1);
return [
  "db" => [
    "host" => "db",
    "database" => "blogs",
    "password" => "mojehaslo",
    "user" => "user_blogs",
  ],
];
