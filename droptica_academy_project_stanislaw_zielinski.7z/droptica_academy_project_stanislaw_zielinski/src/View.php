<?php
declare(strict_types=1);
namespace App;
class View
{
  public function render(
    string $page,
    array $data = [],
    array $userData = [],
    $didUserVotedForThatPost = null
  ): void {
    $data = $this->escape($data);
    require_once "./templates/layout.php";
  }
  private function escape(array $params = []): array
  {
    $clearParams = [];
    foreach ($params as $key => $param) {
      switch (true) {
        case is_array($param):
          $clearParams[$key] = $this->escape($param);
          break;
        case is_int($param):
          $clearParams[$key] = $param;
          break;
        case is_string($param):
          $clearParams[$key] = htmlentities($param, double_encode: false);
          break;
        default:
          $clearParams[$key] = $param;
          break;
      }
    }

    return $clearParams;
  }
}
