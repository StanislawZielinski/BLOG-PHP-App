<?php
declare(strict_types=1);

namespace App;
require_once "./utils/debug.php";

require_once "./View.php";
require_once "./Database.php";
require_once "./Controller.php";
require_once "./Request.php";
// require_once "./EmailValidation.php";

$request = new Request($_GET, $_POST, $_SERVER);

$configuration = require_once "./config/config.php";

try {
  Controller::initConfiguration($configuration);
  $start = new Controller($request);
  $start->run();
  // EmailValidation::initConfiguration($configuration);
  // $emailValidate = new EmailValidation($request);
  // $emailValidate->emailValidate();
} catch (\Throwable $th) {
  throw $th;
}

// $start = new Controller($configuration, $request);
// $start->run();

?>
