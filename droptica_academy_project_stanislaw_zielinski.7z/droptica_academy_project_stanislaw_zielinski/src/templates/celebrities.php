<h4>Celebrities:</h4>
<?php include_once "categoryTemplate.php"; ?>
