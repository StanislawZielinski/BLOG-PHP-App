<?php if (!$admin) {
  die("no permission");
} ?>

<?= $data["success"] ?? $data["unsuccess"] ?>

<button class="btn btn-primary" onclick="history.back()">GO BACK</button>