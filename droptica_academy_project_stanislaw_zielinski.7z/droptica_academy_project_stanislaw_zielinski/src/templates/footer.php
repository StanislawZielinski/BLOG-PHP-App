<div class="footer">
    <div class="container">
        <a href="/?action=info"><button class="btn btn-secondary btn-lg">BLOG INFO</button></a>
        <a href="/?action=author"><button class="btn btn-secondary btn-lg">Author</button></a>
    </div>
</div>