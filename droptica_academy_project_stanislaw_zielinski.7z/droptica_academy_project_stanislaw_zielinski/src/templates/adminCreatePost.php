<?php if (!$admin) {
  die("no permission");
} ?>
<div>
    <h3>create new post</h3>
      <?php if ($data["is_post_invalid"]): ?>
        <h5 class="invalid-data">Invalid data</h5>
      <?php endif; ?>
      <form class="note-form" id="newPost" action="/?action=adminCreatePost" method="post" enctype="multipart/form-data">
        <ul>
          <li class="adminCreateItem">
            <label>Title <span class="required">*</span></label>
            <input type="text" name="title" id="title"  />
          </li>
          <li class="adminCreateItem">
            <label>Description</label>
            <textarea name="description" id="field5" ></textarea>
          </li>
          <li class="adminCreateItem">
            <label>Author <span class="required">*</span></label>
            <input type="text" name="author" id="author"/>
          </li>
          <li class="adminCreateItem">
            <div class="search__box">
                <label for="category">Category:</label>
                <select name="category" id="category">
                <?php foreach (
                  $data["availableCategories"]
                  as $availableCategory
                ): ?>
                    <option value="<?= $availableCategory["category"] ?>">
                    <?= $availableCategory["category"] ?></option>
                <?php endforeach; ?>
                </select>
            </div>
          </li>
            <li class="adminCreateItem">
            <label>Image link</label>
            <input type="text" name="image" style="width: 100%;" value="https://fastly.picsum.photos/id/1/200/300.jpg?hmac=jH5bDkLr6Tgy3oAg5khKCHeunZMHq0ehBZr6vGifPLY"/>
            </li>
            <li class="adminCreateItem">
              <div>Promoted:
                <label >yes<input name="promoted" type="radio" value=1 />
                </label>
                <label >no<input name="promoted" type="radio" value=0 checked/>
                </label>
              </div>
            </li>
            <li class="adminCreateItem">
             <em class="invalid-data"><?php echo $data["errorFileMessage"] ??
               null; ?>  </em>
            <label for="fileToUpload">Upload file</label>
            <input type="file" name="file" id="file">
            <i>* no more than 1MB</i>
            </li>
            <span class="required">*</span>required
            <li class="adminCreateItem">
                <button type="submit" class="btn btn-primary"> Create</button>
            </li>
        </ul>
      </form>
</div>

  <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
  <script src="../js/validationNewPost.js" defer></script>
