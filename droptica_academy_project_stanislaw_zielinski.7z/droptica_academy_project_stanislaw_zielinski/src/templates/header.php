<?php
// dump($userData);
$email = $userData["email"];
$name = $userData["name"];
$admin = $userData["admin"];
?>
<header class="header">
    <div class="container">
    <div class="header-top">
        <a href="/"><h1><i class="far fa-clipboard"></i>BLOGS</h1></a>
        <div class="header__login">
        <?php if ($email !== "Guest"): ?>
            <b>Hello <?= $name ?></b>
            <i><?= $email ?></i>
            <a href="/?action=settings"><button class="btn btn-dark">Settings</button></a>
            <a href="/?action=logout"><button class="btn btn-dark">Log out</button></a>

        <?php else: ?>
            <a href="/?action=login"><button class="btn btn-dark">Log in</button></a>
            <a href="/?action=signup"><button class="btn btn-dark">Sign up</button></a>
        <?php endif; ?>
        </div>
    </div>

    <div class="d-flex flex-wrap justify-content-center border-bottom">
        <ul class="nav nav-pills">
        <li class="nav-item"><a href="/?action=popular" class="nav-link">THE MOST POPULAR</a></li>
        <li class="nav-item"><a href="/?action=war" class="nav-link">WAR</a></li>
        <li class="nav-item"><a href="/?action=sport" class="nav-link">SPORT</a></li>
        <li class="nav-item"><a href="/?action=politics" class="nav-link">POLITICS</a></li>
        <li class="nav-item"><a href="/?action=news" class="nav-link">NEWS</a></li>
        <li class="nav-item"><a href="/?action=celebrities" class="nav-link">CELEBRITIES</a></li>
        <li class="nav-item"><a href="/?action=all" class="nav-link">ALL</a></li>
        </ul>
    </div>
    <?php if ($admin): ?>
        <div class="adminPanel">
            <b >Admin Panel</b>
            <a href="/?action=adminCreatePost"><button class="btn btn-primary">Create Post</button></a>
            <a href="/?action=adminCreateCategory"><button class="btn btn-primary">Categories</button></a>
            <a href="/?action=adminPosts"><button class="btn btn-primary"><b style="color: black;">Posts as list</b> </button></a>
            <a href="/?action=adminUsers"><button class="btn btn-primary"><b style="color: black;">Users as list</b></button></a>

        </div>
    <?php endif; ?>
    </div>
</header>