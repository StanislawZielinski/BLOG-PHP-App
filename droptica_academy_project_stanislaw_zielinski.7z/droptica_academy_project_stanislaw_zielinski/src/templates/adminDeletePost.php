<?php
if (!$admin) {
  die("no permission");
} ?>
<div class="post__custom-wrapper">   
      <div class="card" >
          <div class="card-body card__body">
            <img class="card-img-top card__image" src="<?php echo htmlentities(
              $data["image"]
            ); ?>" alt="Card image cap">
            <h5 class="card-title"><?php echo htmlentities(
              $data["title"]
            ); ?></h5>
            <?php if ($data["stars"] > 10): ?>
              <b><?php echo $data["stars"]; ?>
              <span class="fa fa-star"></span></b>
              <?php else: ?> 
              <?php for ($i = 1; $i <= $data["stars"]; $i++): ?>
              <span class="fa fa-star"></span>
            <?php endfor; ?>
            <?php endif; ?> 
            <p class="card-description"><?php echo htmlentities(
              $data["description"]
            ); ?></p>
            <p class="card-createdDate">created: <?php echo htmlentities(
              $data["created"]
            ); ?></p>
            <p class="card-createdDate">author: <?php echo htmlentities(
              $data["author"]
            ); ?></p>
            <p class="card-createdDate">category: <?php echo htmlentities(
              $data["category"]
            ); ?></p>
        </div>
</div>    
      <div class="button-wrapper">
            <form method="POST">
            <input type="hidden" name="id" value="<?php echo $data["id"]; ?>">
            <button class="btn btn-danger" type="submit">DELETE</button>
        </form>
        
        <button class="btn btn-primary" onclick="history.back()">GO BACK</button>