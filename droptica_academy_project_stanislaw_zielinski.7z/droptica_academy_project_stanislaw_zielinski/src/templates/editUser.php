<?php
if (!$admin) {
  die("no permission");
}

$user = $data["user"];
?>
<h4>EDIT USER</h4>
<form action="" method="POST" id="editUser">
  <div>
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?= $user["name"] ?>">
  </div>
  <div>
        <?php if ($data["is_user_invalid"]): ?>
       <em class="invalid-data">Email already in use</em>
    <?php endif; ?>
    <label for="email">Email</label>
    <!-- <em class="invalid-data">leave empty if email is not changing</em> -->
    <input type="email" name="email" id="email" placeholder="<?= $user[
      "email"
    ] ?>">
  </div>
  <div>
    <label for="password">New Password</label>
    <em class="invalid-data">leave empty if password is not changing</em>
    <input type="password" name="password" id="password">
  </div>
  <div>
    <label for="passwordRepeat">Repeat New Password</label>
    <input type="password" name="passwordRepeat" id="passwordRepeat">
  </div>
  <div>Admin:
    <label >yes<input name="admin" type="radio" value=1 <?php echo $user[
      "admin"
    ]
      ? "checked"
      : null; ?> />
    </label>
    <label >no<input name="admin" type="radio" value=null <?php echo !$user[
      "admin"
    ]
      ? "checked"
      : null; ?>/>
    </label>
  </div>
    <input type="number" name="id" value="<?= $user["id"] ?>" hidden/>
    <button class="btn btn-primary" type="submit" name="submitBtn">SAVE</button>
    <button class="btn btn-primary" onclick="history.back()">GO BACK</button>
</form>
<p>created: <?= $user["created"] ?> </p>

  <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
  <script src="../js/validationChangeUserDataByAdmin.js" defer></script>

