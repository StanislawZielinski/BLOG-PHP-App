<h4>Sport:</h4>
<?php include_once "categoryTemplate.php"; ?>
