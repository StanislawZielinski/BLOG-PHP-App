<h4>War:</h4>
<?php include_once "categoryTemplate.php"; ?>
