<?php
if (!$admin) {
  die("no permission");
}
// dump($data["users"]);

include_once "adminUsersSearchForm.php";

if ($data["users"] === []) {
  echo "0 posts found, please check your query";
}
?>

<!-- ******************* -->
<div class="tbl-header">
  <table cellpadding="0" cellspacing="0" border="0">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>email</th>
        <th>Created</th>
        <th>Admin</th>
        <th>Options</th>
      </tr>
    </thead>
  </table>
</div>
<div class="tbl-content">
  <table cellpadding="0" cellspacing="0" border="0">
    <tbody>
      <?php foreach ($data["users"] ?? [] as $user): ?>
        <tr class="<?php if ($userData["id"] === $user["id"]) {
          echo "itIsYou";
        } ?>">
          <td><?php echo $user["id"]; ?></td>
          <td><?php echo $user["name"]; ?></td>
          <td><?php echo $user["email"]; ?></td>
          <td><?php echo $user["created"]; ?></td>
          <td><?php echo $user["admin"]; ?></td>
          <td>
            <a href="/?action=editUser&id=<?php echo (int) $user["id"]; ?>">
              <button >Edit</button>
            </a>
            <a href="/?action=adminDeleteUser&id=<?php echo (int) $user[
              "id"
            ]; ?>">
              <button >Delete</button>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<!-- pagination -->
<?php include_once "templates/adminPaginationUsers.php"; ?>
