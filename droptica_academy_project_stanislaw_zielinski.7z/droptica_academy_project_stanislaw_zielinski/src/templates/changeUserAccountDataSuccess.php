<div>Your account data are changed!</div>
<a href="/">
    <button class="btn btn-primary">Main Page</button> </a>