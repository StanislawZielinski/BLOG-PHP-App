<h4>News:</h4>
<?php include_once "categoryTemplate.php"; ?>
