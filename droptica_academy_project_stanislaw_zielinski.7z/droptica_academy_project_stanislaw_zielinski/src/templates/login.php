<h4>LOGIN</h4>
<form action="" method="POST">
    <?php if ($data["is_invalid"]): ?>
        <em>Invalid login</em>
    <?php endif; ?>
  <div>
    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars(
      $_POST["email"] ?? ""
    ) ?>">
  </div>
  <div>
    <label for="password">Password</label>
    <input type="password" name="password" id="password">
  </div>

  <!-- <button class="btn btn-primary" type="submit" name="submit">Log in</button> -->
    <button class="btn btn-primary" type="submit" name="submit">Log in</button>
</form>