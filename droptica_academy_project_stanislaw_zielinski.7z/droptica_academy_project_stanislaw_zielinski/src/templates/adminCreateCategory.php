<?php if (!$admin) {
  die("no permission");
}
$existingCategories = $data["existingCategories"];
$emptyCategories = $data["checkIfCategoryIsAssigned"];
?>
<div>
      <form class="" action="<?php echo htmlspecialchars(
        $_SERVER["PHP_SELF"]
      ); ?>?action=adminCreateCategory" method="post" id="createCategory">
            <label>Create new category:</label>
            <?php if ($data["invalid"]): ?>
                <p><em style="color: red;">Error / Category already exist!</em></p>
            <?php endif; ?>
            <input type="text" name="newCategory" id="newCategory" style="width: 100%;"/>
            <button type="submit" class="btn btn-primary">Create</button>
      </form>
      <div class="category-box">
        <ol class="category-list"><b>Existing Categories:</b> 
          <?php foreach ($existingCategories as $existingCategory): ?>
          <li> <?= $existingCategory["category"] ?></li>
          <?php endforeach; ?>
        </ol>
        <?php if (!empty($emptyCategories)): ?>
        <ol class="category-list"><b>Category not assigned to any post</b> 
        <?php endif; ?>
          <?php foreach ($emptyCategories as $emptyCategory): ?>
            <li> <?= $emptyCategory["category"] ?> </br>
              <form method="POST" action="<?php echo htmlspecialchars(
                $_SERVER["PHP_SELF"]
              ); ?>?action=adminCreateCategory">
              <input type="hidden" name="id" value="<?php echo $emptyCategory[
                "id"
              ]; ?>">
                <button class="btn btn-outline-danger btn-sm" type="submit">delete</button>
              </form>
            </li>
          <?php endforeach; ?>
          </ol>
      </div>
      <b>Deleting a category is available only when there is no posts assigned to this category</b>
</div>
<script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
  <script src="../js/validationCategory.js" defer></script>