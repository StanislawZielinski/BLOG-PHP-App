<?php
$order = $data["sort"]["sortOrder"];
$by = $data["sort"]["by"];
$availableCategories = $data["availableCategories"];
$phrase = $data["phrase"] ?? null;
?>
<div>
    <form class="settings-form" action="/" method="GET">
    <input type="text" name="action" value="adminPosts" hidden>
    <div class="search__box">
        <label for="phrase"><b>Search title:</b> </label><input type="text" name="phrase" value="<?php echo $phrase; ?>">
    </div>
        <div class="search__box">
            <label for="category"><b>Pick category:</b></label>
            <select name="category" id="category">
                <option value="category">ALL</option>
            <?php foreach (
              $availableCategories
              as $key => $availableCategory
            ): ?>
            <option value="<?= $availableCategory[
              "category"
            ] ?>"><?= $availableCategory["category"] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="search__box"><b>Sort by:</b> 
        <label >Title:<input name="sortBy" type="radio" value="title" <?php echo $by ===
        "title"
          ? "checked"
          : ""; ?>/>
        </label>
        <label >Date:<input name="sortBy" type="radio" value="created" <?php echo $by ===
        "created"
          ? "checked"
          : ""; ?>/>
        </label>
        <label >Stars:<input name="sortBy" type="radio" value="stars" <?php echo $by ===
        "stars"
          ? "checked"
          : ""; ?>/>
        </label>
        <label >Promoted:<input name="sortBy" type="radio" value="promoted" <?php echo $by ===
        "promoted"
          ? "checked"
          : ""; ?>/>
        </label></br>
        </div>
    <div class="search__box"><b>Sort order:</b> 
        <label >Ascending <input name="sortOrder" type="radio" value="asc" <?php echo $order ===
        "asc"
          ? "checked"
          : ""; ?>/></label>
        <label >Descending <input name="sortOrder" type="radio" value="desc" <?php echo $order ===
        "desc"
          ? "checked"
          : ""; ?>/></label>
    </div>
    <input type="submit" value="Sort" class="btn btn-info">
    </form>
</div>