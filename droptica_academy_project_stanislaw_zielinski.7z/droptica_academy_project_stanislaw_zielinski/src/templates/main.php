<?php
$recent = $data["recent"];
$mostStars = $data["mostStars"];
$promoted = $data["promoted"];
?>

<div class="mainPage__div"><?php include_once "main/promoted.php"; ?></div>
<div class="mainPage__div"><?php include_once "main/recent.php"; ?></div>
<div class="mainPage__div"><?php include_once "main/popular.php"; ?></div>

