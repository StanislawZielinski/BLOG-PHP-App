<?php
$currentPageNumber = $data["pagination"]["pageNumber"];
$pages = $data["pages"] ?? 1;
$phrase = $data["phrase"];
$sortBy = $data["sort"]["by"];
$sortOrder = $data["sort"]["sortOrder"];
// dump($data);
$paginationUrl = "?action=adminUsers&phrase=$phrase&sortBy=$sortBy&sortOrder=$sortOrder";
?>
<ul class="pagination">
  <?php if ($currentPageNumber !== 1): ?>
    <li>
      <a href="<?= $paginationUrl ?>&pageNumber=<?php echo $currentPageNumber -
  1; ?>">
        <button ><<</button>
      </a>
    </li>
    <?php endif; ?>
  <?php for ($i = 1; $i <= $pages; $i++): ?> 
    <li>
      <a href="<?= $paginationUrl ?>&pageNumber=<?php echo $i; ?>">
        <button <?php if (
          $i === $currentPageNumber
        ): ?> style = "background-color: cadetblue;"; <?php endif; ?> ?><?php echo $i; ?></button>
      </a>
    </li>
  <?php endfor; ?>
  <?php if ($currentPageNumber < $pages): ?>
    <li>
      <a href="<?= $paginationUrl ?>&pageNumber=<?php echo $currentPageNumber +
  1; ?>">
        <button >>></button>
      </a>
    </li>
    <?php endif; ?>
</ul>