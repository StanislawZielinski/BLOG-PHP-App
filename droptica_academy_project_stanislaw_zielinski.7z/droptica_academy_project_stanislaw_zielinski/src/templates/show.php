<?php

$email = $userData["email"]; ?>
<div class="post__custom-wrapper">   
      <div class="card" >
          <div class="card-body card__body">
            <img class="card-img-top card__image" src="<?php echo htmlentities(
              $data["image"]
            ); ?>" alt="Card image cap">
            <h5 class="card-title"><?php echo htmlentities(
              $data["title"]
            ); ?></h5>
            <?php if ($data["stars"] > 10): ?>
              <b><?php echo $data["stars"]; ?>
              <span class="fa fa-star"></span></b>
              <?php else: ?> 
              <?php for ($i = 1; $i <= $data["stars"]; $i++): ?>
              <span class="fa fa-star"></span>
            <?php endfor; ?>
            <?php endif; ?> 
            <p class="card-description"><?php echo htmlentities(
              $data["description"]
            ); ?></p>
            <p class="card-createdDate">created: <?php echo htmlentities(
              $data["created"]
            ); ?></p>
            <p class="card-createdDate">author: <?php echo htmlentities(
              $data["author"]
            ); ?></p>
            <p class="card-createdDate">category: <?php echo htmlentities(
              $data["category"]
            ); ?></p>
            <div class="invalid-data">
              <p class="">attachments:</p>
              <?php if ($data["fileName"]): ?>
                <a href="download.php?file=<?php echo $data[
                  "fileId"
                ]; ?>">>>><?= $data["fileName"] ?><<<</a>
              <?php else: ?>
                <p>no files</p>
              <?php endif; ?>
            </div>
          </div>
      </div>    
      <div class="button-wrapper">
        <a href="/"><button class="btn btn-primary">BACK TO THE MAIN PAGE</button></a>
        <button class="btn btn-primary" onclick="history.back()">GO BACK</button>
        <?php if ($email !== "Guest"): ?>
        <form action="" method="POST">
          <?php if ($didUserVotedForThatPost): ?>
            <p>You already gave your <span class="fa fa-star"></span> to this post!</p>
          <?php else: ?>  
          <p>reward with <span class="fa fa-star"></span></p>
          <?php endif; ?>
          <input type="submit" value="Add Star!" class="btn btn-info" name="star" <?php if (
            $didUserVotedForThatPost
          ) {
            echo "disabled";
          } ?> >
        </form>   
        <?php endif; ?>
      </div>
</div>

