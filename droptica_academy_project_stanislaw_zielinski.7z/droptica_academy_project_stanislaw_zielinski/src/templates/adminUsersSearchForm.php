<?php
$order = $data["sort"]["sortOrder"];
$by = $data["sort"]["by"];
$phrase = $data["phrase"] ?? null;
?>
<div>
    <form class="settings-form" action="/" method="GET">
    <input type="text" name="action" value="adminUsers" hidden>
    <div class="search__box">
        <label for="phrase"><b>Search name:</b> </label><input type="text" name="phrase" value="<?php echo $phrase; ?>">
    </div>
        <div class="search__box"><b>Sort by:</b> 
        <label >Name:<input name="sortBy" type="radio" value="name" <?php echo $by ===
        "name"
          ? "checked"
          : ""; ?>/>
        </label>
        <label >Email:<input name="sortBy" type="radio" value="email" <?php echo $by ===
        "email"
          ? "checked"
          : ""; ?>/>
        </label>
        <label >Created:<input name="sortBy" type="radio" value="created" <?php echo $by ===
        "created"
          ? "checked"
          : ""; ?>/>
        </label>
        <label >Admin:<input name="sortBy" type="radio" value="admin" <?php echo $by ===
        "admin"
          ? "checked"
          : ""; ?>/>
        </label></br>
        </div>
    <div class="search__box"><b>Sort order:</b> 
        <label >Ascending <input name="sortOrder" type="radio" value="asc" <?php echo $order ===
        "asc"
          ? "checked"
          : ""; ?>/></label>
        <label >Descending <input name="sortOrder" type="radio" value="desc" <?php echo $order ===
        "desc"
          ? "checked"
          : ""; ?>/></label>
    </div>
    <input type="submit" value="Sort" class="btn btn-info">
    </form>
</div>