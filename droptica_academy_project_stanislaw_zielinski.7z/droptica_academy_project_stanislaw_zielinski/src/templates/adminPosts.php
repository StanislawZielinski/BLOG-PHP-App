<?php
if (!$admin) {
  die("no permission");
}
include_once "adminSearchForm.php";

if ($data["posts"] === []) {
  echo "0 posts found, please check your query";
}
?>

<!-- ******************* -->
<div class="tbl-header">
  <table cellpadding="0" cellspacing="0" border="0">
    <thead>
      <tr>
        <th>Id</th>
        <th>Title</th>
        <th>Description</th>
        <th>Image</th>
        <th>Category</th>
        <th>Created</th>
        <th>Author</th>
        <th>Stars</th>
        <th>Promoted</th>
        <th>File</th>
        <th>Options</th>
      </tr>
    </thead>
  </table>
</div>
<div class="tbl-content">
  <table cellpadding="0" cellspacing="0" border="0">
    <tbody>
      <?php foreach ($data["posts"] ?? [] as $post): ?>
        <tr>
          <td><?php echo (int) $post["id"]; ?></td>
          <td><?php echo $post["title"]; ?></td>
          <td>
            <button style="color: black;" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $post[
              "id"
            ]; ?>">
            open
            </button>
          </td>
          <td>
            <div class="table__img-wrapper">
                <img src="<?php echo htmlentities(
                  $post["image"]
                ); ?>" alt="Card image cap">
            </div>
          </td>
          <td><?php echo $post["category"]; ?></td>
          <td><?php echo $post["created"]; ?></td>
          <td><?php echo $post["author"]; ?></td>
          <td><?php echo $post["stars"]; ?></td>
          <td><?php echo $post["promoted"]; ?></td>
          <td><?php echo $post["fileName"]; ?></td>
          <td>
            <a href="/?action=show&id=<?php echo (int) $post["id"]; ?>">
              <button >Show</button>
            </a>
            <a href="/?action=editPost&id=<?php echo (int) $post["id"]; ?>">
              <button >Edit</button>
            </a>
            <a href="/?action=adminDeletePost&id=<?php echo (int) $post[
              "id"
            ]; ?>">
              <button >Delete</button>
            </a>
          </td>
        </tr>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal<?php echo $post[
          "id"
        ]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo $post[
                  "title"
                ]; ?></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo $post["description"]; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
        </div>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<!-- pagination -->
<?php include_once "templates/adminPaginationPosts.php";
