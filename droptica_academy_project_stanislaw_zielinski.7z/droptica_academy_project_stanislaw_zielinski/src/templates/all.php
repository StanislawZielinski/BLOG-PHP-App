<h4>Recent posts:</h4>
<?php include_once "categoryTemplate.php"; ?>
