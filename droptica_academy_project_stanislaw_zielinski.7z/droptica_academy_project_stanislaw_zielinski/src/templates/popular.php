<h4>The most popular posts:</h4>
<?php include_once "categoryTemplate.php"; ?>
