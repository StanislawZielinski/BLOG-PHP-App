<?php
if (!$admin) {
  die("no permission");
}
$is_user_invalid = false;
$id = $data["id"];
$name = $data["name"];
$email = $data["email"];
$admin = $data["admin"];
$created = $data["created"];
if ($id === $userData["id"]) {
  $is_user_invalid = true;
}
?>
<div>
    <ul>
        <li><h4>name:<?= $name ?></h4></li>
        <li><h4>email:<?= $email ?></h4></li>
        <li><p>admin:<?= $admin ? "yes" : "no" ?></p></li>
        <li><p>created:<?= $created ?></p></li>
    </ul>
</div>
<div class="button-wrapper">
    <?php if (!$is_user_invalid): ?>
    <form method="POST">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <button class="btn btn-danger" type="submit">DELETE</button>
    </form>
    <?php else: ?>
        <p>Unable to delete yourself :)</p>
        <?php endif; ?>
<button class="btn btn-primary" onclick="history.back()">GO BACK</button>
</div>