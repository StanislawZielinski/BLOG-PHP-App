<div>Signup success!</div>
<p>You can now log in here >>> <a href="?action=login">
    <button class="btn btn-primary">Log in</button> </a><<<</p>