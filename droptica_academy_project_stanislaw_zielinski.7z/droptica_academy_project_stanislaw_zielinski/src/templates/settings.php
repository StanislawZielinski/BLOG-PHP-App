<h4>CHANGE YOUR ACCOUNT DATA</h4>
<form action="" method="POST" id="changeUserDataByUser">
    <div>
    <label for="newName">Name</label>
    <input type="text" name="newName" id="newName" value="<?= $userData[
      "name"
    ] ?>" >
  </div>
    <div>
    <label for="newEmail">New Email</label>
    <input type="email" name="newEmail" id="newEmail" placeholder="<?= $userData[
      "email"
    ] ?>" >
  </div>
    <?php if ($data["is_invalid"]): ?>
       <em style="color: red;">Invalid password</em>
    <?php endif; ?>
    <div>
    <label for="oldPassword">Old Password</label>
    <input type="password" name="oldPassword" id="oldPassword">
  </div>
  <div>
    <label for="newPassword">New Password</label>
    <input type="password" name="newPassword" id="newPassword">
  </div>
  <div>
    <label for="passwordRepeat">Repeat new Password</label>
    <input type="password" name="newPasswordRepeat" id="newPasswordRepeat">
  </div>
    <button class="btn btn-primary" type="submit" name="submitBtn">Save</button>
</form>

  <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
  <script src="../js/validationChangeUserDataByUser.js" defer></script>