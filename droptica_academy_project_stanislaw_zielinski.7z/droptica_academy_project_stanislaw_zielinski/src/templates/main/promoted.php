<div class="promoted-wrapper">
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php foreach ($promoted ?? [] as $post): ?> 
            <div class="carousel-item">
                <a href="/?action=show&id=<?php echo (int) $post["id"]; ?>">
                <img src="<?php echo $post[
                  "image"
                ]; ?>" class="d-block w-100 h-50 promoted-image" alt="...">
                <div class="carousel-caption d-md-block">
                <h5><?php echo $post["title"]; ?></h5>
                <p class="promoted-description"><?php echo $post[
                  "description"
                ]; ?></p>
                </div>
                </a>
            </div>
        <?php endforeach; ?>
    <button class="carousel-control-prev icon-color" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next icon-color" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon " aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
    </div>
    <div class="posts-wrapper">   
    <?php foreach ($promoted ?? [] as $post): ?>
            <div class="card card__promoted"style="width: 15rem;" >
                <div class="card-body">
                    <a href="/?action=show&id=<?php echo (int) $post["id"]; ?>">
                        <h5 class="card-title"><?php echo htmlentities(
                          $post["title"]
                        ); ?></h5>
                        <?php if ($post["stars"] > 10): ?>
                          <b><?php echo $post["stars"]; ?>
                          <span class="fa fa-star"></span></b>
                          <?php else: ?> 
                          <?php for ($i = 1; $i <= $post["stars"]; $i++): ?>
                          <span class="fa fa-star"></span>
                        <?php endfor; ?>
                        <?php endif; ?> 
                        <img class="card-img-top card-img-promoted" src="<?php echo htmlentities(
                          $post["image"]
                        ); ?>" alt="Card image cap">
                        <p class="card-text card__text"><?php echo htmlentities(
                          $post["description"]
                        ); ?></p>
                    </a>
                </div>
            </div>    
        <?php endforeach; ?>
    </div>
</div>

