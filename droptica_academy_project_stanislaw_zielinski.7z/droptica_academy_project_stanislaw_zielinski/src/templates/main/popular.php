<h4 class="test2"> <a href="/?action=popular" class="test">The most popular posts:</a></h4>
<div class="posts-wrapper">   
   <?php foreach ($mostStars ?? [] as $post): ?>
        <div class="card" style="width: 15rem;">
            <div class="card-body card__body">
                <a href="/?action=show&id=<?php echo (int) $post["id"]; ?>">
                    <h5 class="card-title"><?php echo htmlentities(
                      $post["title"]
                    ); ?></h5>
                    <?php if ($post["stars"] > 10): ?>
                      <b><?php echo $post["stars"]; ?>
                      <span class="fa fa-star"></span></b>
                      <?php else: ?> 
                      <?php for ($i = 1; $i <= $post["stars"]; $i++): ?>
                      <span class="fa fa-star"></span>
                    <?php endfor; ?>
                    <?php endif; ?> 
                    <img class="card-img-top" src="<?php echo htmlentities(
                      $post["image"]
                    ); ?>" alt="Card image cap">
                    <p class="card-text card__text"><?php echo htmlentities(
                      $post["description"]
                    ); ?></p>
                </a>
            </div>
        </div>    
    <?php endforeach; ?>
</div>