<h4>Politics:</h4>
<?php include_once "categoryTemplate.php"; ?>
