<?php if (!$admin) {
  die("no permission");
} ?>

<div>
  <h3>edit post</h3>
    <?php if ($data["is_post_invalid"]): ?>
      <h5 class="invalid-data">Invalid data</h5>
    <?php endif; ?>
    <form action="\?action=adminDeleteFile&&fileId=<?= $data["post"][
      "fileId"
    ] ?>" method="POST" id="deleteForm"></form>
    <form class="note-form" id="newPost" action="/?action=editPost" method="POST">

        <ul>
          <li class="adminCreateItem">
            <label>Title <span class="required">*</span></label>
            <input  type="text" name="title" id="title" value="<?= $data[
              "post"
            ]["title"] ?>"  />
          </li>
          <li class="adminCreateItem">
            <label>Description</label>
            <textarea form="newPost" name="description" id="field5"><?= $data[
              "post"
            ]["description"] ?> </textarea>
          </li>
          <li class="adminCreateItem">
            <label>Author <span class="required">*</span></label>
            <input form="newPost" type="text" name="author" id="author" value="<?= $data[
              "post"
            ]["author"] ?>"/>
          </li>
          <li class="adminCreateItem">
            <div class="search__box">
                <label for="category">Category:</label>
                <select form="newPost" name="category" id="category">
                    <option value="<?= $data["post"]["category"] ?>">
                    <?= $data["post"]["category"] ?></option>
                <?php foreach (
                  $data["availableCategories"]
                  as $availableCategory
                ): ?>
                <?php if (
                  $data["post"]["category"] !== $availableCategory["category"]
                ): ?>
                    <option form="newPost" value="<?= $availableCategory[
                      "category"
                    ] ?>">
                    <?= $availableCategory["category"] ?></option>
                    <?php endif; ?>
                <?php endforeach; ?>
                </select>
            </div>
          </li>
            <li class="adminCreateItem">
                <label>Image link</label>
                <input form="newPost" type="text" name="image" style="width: 100%;" 
                value="<?= $data["post"]["image"] ?>"/>
            </li>
            <li class="adminCreateItem">
              <div>Promoted:
                <label >yes<input form="newPost" name="promoted" type="radio" value=1 
                <?php echo $data["post"]["promoted"] ? "checked" : null; ?>   />
                </label>
                <label >no<input form="newPost" name="promoted" type="radio" value=0 <?php echo !$data[
                  "post"
                ]["promoted"]
                  ? "checked"
                  : null; ?>/>
                </label>
              </div>
            </li>
            <li>
            <div class="invalid-data">
              <p class=""><b>attachments:</b> </p>
              <?php if ($data["post"]["fileName"]): ?>
                <a href="download.php?file=<?php echo $data["post"][
                  "fileId"
                ]; ?>">>>><?= $data["post"]["fileName"] ?><<<</a>
                    <input type="hidden" form="deleteForm" name="fileId" id="fileId" value="<?= $data[
                      "post"
                    ]["fileId"] ?>">
                    <input type="hidden" form="deleteForm" name="postId" id="postId" value="<?= $data[
                      "post"
                    ]["id"] ?>">
                    <button class="btn btn-danger" form="deleteForm" type="submit">DELETE FILE</button>            
              <?php else: ?>
                <p>no files</p>
              <?php endif; ?>
            </div>
            </li>
            <span class="required">*</span>required
            <li class="adminCreateItem">
              <input type="number" form="newPost"  name="id" value="<?= $data[
                "post"
              ]["id"] ?>" hidden/>
                <button form="newPost" type="submit" name="btnEdit" class="btn btn-primary">SAVE</button>
            </li>

        </ul>
</form>
      <button class="btn btn-primary" onclick="history.back()">GO BACK</button>
</div>

  <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
  <script src="../js/validationEditPost.js" defer></script>

