<?php
declare(strict_types=1);

namespace App;

use Error;
use PDO;
use PDOException;

class Database
{
  private PDO $conn;
  public function __construct(array $config)
  {
    try {
      $this->createConnetcion($config);
    } catch (PDOException $e) {
      echo "PDOException";
      throw $e;
    } catch (\Throwable $th) {
      echo "connection error";
      throw $th;
    }
  }

  private function createConnetcion(array $config)
  {
    $dsn = "mysql:dbname={$config["database"]};host={$config["host"]}";

    $this->conn = new PDO($dsn, $config["user"], $config["password"]);
  }
  // POSTS ******************************
  // PREPARE STMT DONE
  public function getAllPosts($pagination): array
  {
    try {
      $pageNumber = $pagination["pageNumber"];

      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $stmt = $this->conn->prepare(
        "SELECT id,title,description,image,stars,category FROM blogs WHERE NOT title IS NULL ORDER BY created DESC LIMIT :offset, :pageSize"
      );
      $stmt->bindParam(":pageSize", $pageSize, PDO::PARAM_INT);
      $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
      $stmt->execute();
      $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function getPosts($category, $pagination): array
  {
    try {
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $stmt = $this->conn->prepare(
        "SELECT id,title,description,image,stars,category FROM blogs WHERE NOT title IS NULL AND category=:category ORDER BY created DESC LIMIT :offset, :pageSize"
      );
      $stmt->bindParam(":pageSize", $pageSize, PDO::PARAM_INT);
      $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
      $stmt->bindParam(":category", $category, PDO::PARAM_STR);
      $stmt->execute();
      $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function getTheMostPopularPosts($pagination): array
  {
    try {
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $stmt = $this->conn->prepare(
        "SELECT id,title,description,image,stars,category FROM blogs WHERE NOT title IS NULL ORDER BY stars DESC LIMIT :offset, :pageSize"
      );
      $stmt->bindParam(":pageSize", $pageSize, PDO::PARAM_INT);
      $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
      $stmt->execute();
      $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function getPromotedPosts($pagination): array
  {
    try {
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $stmt = $this->conn->prepare(
        "SELECT id,title,description,image,stars,category,promoted FROM blogs WHERE NOT title IS NULL ORDER BY promoted DESC LIMIT :offset, :pageSize"
      );
      $stmt->bindParam(":pageSize", $pageSize, PDO::PARAM_INT);
      $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
      $stmt->execute();
      $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function getPost($id): array
  {
    try {
      $stmt = $this->conn->prepare(
        "SELECT * FROM blogs WHERE NOT title IS NULL AND id=:id"
      );
      $stmt->bindParam(":id", $id, PDO::PARAM_INT);
      $stmt->execute();
      $post = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      return $post;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function countInCategory($category): int
  {
    try {
      $stmt = $this->conn->prepare(
        "SELECT count(*) AS nr FROM blogs WHERE NOT title IS NULL AND category=:category"
      );
      $stmt->bindParam(":category", $category, PDO::PARAM_STR);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      $numberOfPostsInCategory = (int) $result["nr"];
      $stmt = null;
      return $numberOfPostsInCategory ?? 0;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function countAllPosts(): int
  {
    try {
      $stmt = $this->conn->prepare(
        "SELECT count(*) AS nr FROM blogs WHERE NOT title IS NULL"
      );
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      $numberOfAllPosts = (int) $result["nr"];
      $stmt = null;
      return $numberOfAllPosts ?? 0;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function addStar($id)
  {
    try {
      $stmt = $this->conn->prepare(
        "UPDATE blogs SET stars=stars+1 WHERE id=$id"
      );
      $stmt->execute();
      $stmt = null;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function deletePost(int $id): void
  {
    try {
      $stmt = $this->conn->prepare(
        "DELETE FROM blogs WHERE id=:id LIMIT :limit"
      );
      $limit = 1;
      $stmt->bindParam(":id", $id, PDO::PARAM_INT);
      $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
      $stmt->execute();
      $stmt = null;
    } catch (\Throwable $th) {
      throw $th;
    }
  }

  // USERS ******************************
  // USERS ******************************

  // PREPARE STMT DONE
  public function createUser(array $data)
  {
    try {
      $stmt = $this->conn->prepare(
        "INSERT INTO users(name, email, password_hash) VALUES(?,?,?)"
      );
      $stmt->execute([$data["name"], $data["email"], $data["password_hash"]]);
      $stmt = null;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function getUser($email)
  {
    try {
      $stmt = $this->conn->prepare("SELECT * FROM users WHERE email=:email");
      $stmt->bindParam(":email", $email, PDO::PARAM_STR);
      $stmt->execute();
      $user = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      return $user;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function checkIfEmailIsAvaliable($emailFromUrl)
  {
    try {
      $stmt = $this->conn->prepare(
        "SELECT COUNT(*) FROM users WHERE email=:emailFromUrl"
      );
      $stmt->bindParam(":emailFromUrl", $emailFromUrl, PDO::PARAM_STR);
      $stmt->execute();
      $count = $stmt->fetchColumn();
      $stmt = null;
      return $count;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function updateUserDataWithoutNewPassword(array $newUserData)
  {
    try {
      $stmt = $this->conn->prepare(
        "UPDATE users SET name=?,email=? WHERE id=?"
      );
      $result = $stmt->execute([
        $newUserData["name"],
        $newUserData["email"],
        $newUserData["id"],
      ]);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function updateUserDataWithNewPassword(array $newUserData)
  {
    try {
      $stmt = $this->conn->prepare(
        "UPDATE users SET name=?,email=?,password_hash=? WHERE id=?"
      );
      $result = $stmt->execute([
        $newUserData["name"],
        $newUserData["email"],
        $newUserData["password_hash"],
        $newUserData["id"],
      ]);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // STARS
  // PREPARE STMT DONE
  public function markAsCheckedInStarsDB(int $postId, int $userId)
  {
    try {
      $stmt = $this->conn->prepare(
        "INSERT INTO stars (user_id, post_id, voted) VALUES (?, ?, ?)"
      );
      $result = $stmt->execute([$userId, $postId, 1]);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function didUserVotedForThatPost(int $postId, int $userId)
  {
    try {
      $stmt = $this->conn->prepare(
        "SELECT voted FROM stars WHERE user_id=? AND post_id=?"
      );
      $stmt->execute([$userId, $postId]);
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      return $result;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }

  // ADMIN********************

  // PREPARE STMT DONE
  public function adminGetPosts(
    $pagination,
    string $sortOrder,
    string $sortBy,
    string $category
  ): array {
    try {
      $conditions = [];
      $parameters = [];
      if ($category !== "category") {
        $conditions[] = "category=:category ";
        $parameters[] = $category;
      }
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      // ORDER
      $order = $this->white_list(
        $sortBy,
        ["title", "created", "stars", "promoted"],
        "Invalid field name"
      );
      $direction = $this->white_list(
        $sortOrder,
        ["asc", "desc"],
        "Invalid ORDER BY direction"
      );
      // SQL
      $sql = "SELECT * FROM blogs WHERE NOT title IS NULL ";
      if ($conditions) {
        $sql .= " AND " . implode($conditions);
      }
      $stmt = $this->conn->prepare(
        $sql . "ORDER BY $order $direction LIMIT :offset, :pageSize"
      );
      if ($category !== "category") {
        $stmt->bindParam(":category", $category, PDO::PARAM_STR);
      }
      $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
      $stmt->bindParam(":pageSize", $pageSize, PDO::PARAM_INT);
      $stmt->execute();
      $post = $stmt->fetchALL(PDO::FETCH_ASSOC);
      $stmt = null;
      return $post;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function adminGetPostsWithPhrase(
    ?string $phrase,
    $pagination,
    string $sortOrder,
    string $sortBy,
    string $category
  ): array {
    try {
      $conditions = [];
      $parameters = [];
      if ($category !== "category") {
        $conditions[] = "category = ? ";
        $parameters[] = $category;
      }
      if (!empty($phrase)) {
        $conditions[] = "title LIKE ?";
        $parameters[] = "%" . $phrase . "%";
      }

      // ORDER
      $order = $this->white_list(
        $sortBy,
        ["title", "created", "stars", "promoted"],
        "Invalid field name"
      );
      $direction = $this->white_list(
        $sortOrder,
        ["asc", "desc"],
        "Invalid ORDER BY direction"
      );
      // PAGINATION
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $parameters[] = $offset;
      $parameters[] = $pageSize;
      $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
      // SQL
      $sql = "SELECT * FROM blogs WHERE NOT title IS NULL";
      if ($conditions) {
        $sql .= " AND " . implode(" AND ", $conditions);
      }
      $stmt = $this->conn->prepare(
        $sql . " ORDER BY $order $direction LIMIT ?, ?"
      );
      $stmt->execute($parameters);
      $post = $stmt->fetchALL(PDO::FETCH_ASSOC);
      $stmt = null;
      return $post;
    } catch (PDOException $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function countAdminGetPostsWithPhrase($phrase, $category): int
  {
    try {
      $conditions = [];
      $parameters = [];
      if ($category !== "category") {
        $conditions[] = "category = ? ";
        $parameters[] = $category;
      }
      if (!empty($phrase)) {
        $conditions[] = "title LIKE ?";
        $parameters[] = "%" . $phrase . "%";
      }
      // SQL
      $sql = "SELECT count(*) AS nr FROM blogs WHERE NOT title IS NULL";
      if ($conditions) {
        $sql .= " AND " . implode("AND ", $conditions);
      }
      $stmt = $this->conn->prepare($sql);
      $stmt->execute($parameters);
      $numberOfPost = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      $numberOfPost = (int) $numberOfPost["nr"];
      return $numberOfPost ?? 0;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function countAdminInCategory($category): int
  {
    try {
      $conditions = [];
      $parameters = [];
      if ($category !== "category") {
        $conditions[] = "category = ? ";
        $parameters[] = $category;
      }
      // SQL
      $sql = "SELECT count(*) AS nr FROM blogs WHERE NOT title IS NULL";
      if ($conditions) {
        $sql .= " AND " . implode("AND ", $conditions);
      }
      $stmt = $this->conn->prepare($sql);
      $stmt->execute($parameters);

      $numberOfPost = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      $numberOfPost = (int) $numberOfPost["nr"];
      return $numberOfPost ?? 0;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  public function getCategories(): array
  {
    try {
      $query = "SELECT DISTINCT category FROM blogs";
      $result = $this->conn->query($query);
      $blogs = $result->fetchAll(PDO::FETCH_ASSOC);
      return $blogs;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function createNewCategory(string $newCategory)
  {
    try {
      $stmt = $this->conn->prepare("INSERT INTO blogs (category) VALUES (?)");
      $stmt->execute([$newCategory]);
      $stmt = null;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  public function checkIfCategoryIsAssigned()
  {
    try {
      $query = "SELECT id, title, category FROM blogs WHERE title IS NULL";
      $result = $this->conn->query($query);
      $blogs = $result->fetchAll(PDO::FETCH_ASSOC);
      return $blogs;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function deleteCategory(int $idDeleteCategory)
  {
    try {
      $stmt = $this->conn->prepare("DELETE FROM blogs WHERE id=:id LIMIT 1");
      $stmt->bindParam(":id", $idDeleteCategory, PDO::PARAM_INT);
      $stmt->execute();
      $stmt = null;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function createNewPost(array $postData)
  {
    try {
      $data = [
        "title" => $postData["title"],
        "description" => $postData["description"],
        "author" => $postData["author"],
        "category" => $postData["category"],
        "image" => $postData["image"],
        "promoted" => $postData["promoted"],
        "fileName" => $postData["fileName"],
        "fileId" => $postData["fileId"],
      ];
      $sql = "INSERT INTO blogs (title, author, description, image, category, promoted, fileName, fileId ) 
      VALUES(:title, :author,:description,:image, :category, :promoted, :fileName, :fileId)";
      $stmt = $this->conn->prepare($sql);
      $stmt->execute($data);
      $stmt = null;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }

  // PREPARE STMT DONE
  public function editPost(array $postData)
  {
    try {
      $data = [
        "id" => $postData["id"],
        "title" => $postData["title"],
        "description" => $postData["description"],
        "author" => $postData["author"],
        "category" => $postData["category"],
        "image" => $postData["image"],
        "promoted" => $postData["promoted"],
      ];
      $sql =
        "UPDATE blogs SET title=:title, author=:author, description=:description, image=:image, category=:category, promoted=:promoted WHERE id=:id LIMIT 1";
      $stmt = $this->conn->prepare($sql);
      $stmt->execute($data);
      $stmt = null;
    } catch (PDOException $th) {
      dump($th);
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
    }
  }
  // PREPARE STMT DONE
  public function getUsersWithPhrase(
    ?string $phrase,
    $pagination,
    string $sortOrder,
    string $sortBy
  ): array {
    try {
      if (!empty($phrase)) {
        $conditions[] = " WHERE name LIKE ?";
        $parameters[] = "%" . $phrase . "%";
      }
      // ORDER
      $order = $this->white_list(
        $sortBy,
        ["name", "email", "created", "admin"],
        "Invalid field name"
      );
      $direction = $this->white_list(
        $sortOrder,
        ["asc", "desc"],
        "Invalid ORDER BY direction"
      );
      // PAGINATION
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $parameters[] = $offset;
      $parameters[] = $pageSize;
      $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
      $sql = "SELECT id, name, email,created, admin FROM users";
      if ($conditions) {
        $sql .= implode($conditions);
      }
      $stmt = $this->conn->prepare(
        $sql . " ORDER BY $order $direction LIMIT ?, ?"
      );
      $stmt->execute($parameters);
      $users = $stmt->fetchALL(PDO::FETCH_ASSOC);
      $stmt = null;
      return $users;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function countUsersWithPhrase($phrase): int
  {
    try {
      if (!empty($phrase)) {
        $conditions[] = " WHERE name LIKE ?";
        $parameters[] = "%" . $phrase . "%";
      }
      $sql = "SELECT count(*) AS nr FROM users";
      if ($conditions) {
        $sql .= implode($conditions);
      }
      $stmt = $this->conn->prepare($sql);
      $stmt->execute($parameters);
      $numberOfUsers = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      $numberOfUsers = (int) $numberOfUsers["nr"];
      return $numberOfUsers ?? 0;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function getUsers(
    $pagination,
    string $sortOrder,
    string $sortBy
  ): array {
    try {
      // ORDER
      $order = $this->white_list(
        $sortBy,
        ["name", "email", "created", "admin"],
        "Invalid field name"
      );
      $direction = $this->white_list(
        $sortOrder,
        ["asc", "desc"],
        "Invalid ORDER BY direction"
      );
      // PAGINATION
      $pageNumber = $pagination["pageNumber"];
      $pageSize = $pagination["pageSize"];
      $offset = ($pageNumber - 1) * $pageSize;
      $parameters[] = $offset;
      $parameters[] = $pageSize;
      $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
      $sql = "SELECT id, name, email,created, admin FROM users";
      $stmt = $this->conn->prepare(
        $sql . " ORDER BY $order $direction LIMIT ?, ?"
      );
      $stmt->execute($parameters);
      $users = $stmt->fetchALL(PDO::FETCH_ASSOC);
      $stmt = null;
      return $users;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }

  public function countAllUsers(): int
  {
    try {
      $query = "SELECT count(*) AS nr FROM users";
      $result = $this->conn->query($query);
      $numberOfUsers = $result->fetch(PDO::FETCH_ASSOC);
      $numberOfUsers = (int) $numberOfUsers["nr"];
      return $numberOfUsers ?? 0;
    } catch (\Throwable $th) {
      throw "database error";
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function getUserById($userId): array
  {
    try {
      $stmt = $this->conn->prepare("SELECT * FROM users WHERE id=:id LIMIT 1");
      $stmt->bindValue("id", $userId, PDO::PARAM_INT);
      $stmt->execute();
      $user = $stmt->fetch(PDO::FETCH_ASSOC);
      $stmt = null;
      return $user;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      dump($errors);
      throw $th;
    }
  }

  // PREPARE STMT DONE
  public function adminEditUserDataWithoutNewPassword(array $userChangeData)
  {
    try {
      $sql =
        "UPDATE users SET name=:name, admin=:admin, email=:email WHERE id=:id LIMIT 1";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindParam(":name", $userChangeData["name"], PDO::PARAM_STR);
      $stmt->bindParam(":admin", $userChangeData["admin"], PDO::PARAM_INT);
      $stmt->bindParam(":email", $userChangeData["email"], PDO::PARAM_STR);
      $stmt->bindParam(":id", $userChangeData["id"], PDO::PARAM_INT);
      $user = $stmt->execute();
      $stmt = null;
      return $user;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function adminEditUserDataWithNewPassword(array $userChangeData)
  {
    try {
      $sql =
        "UPDATE users SET name=:name, admin=:admin, email=:email,password_hash=:password_hash WHERE id=:id LIMIT 1";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindParam(":name", $userChangeData["name"], PDO::PARAM_STR);
      $stmt->bindParam(":admin", $userChangeData["admin"], PDO::PARAM_INT);
      $stmt->bindParam(":email", $userChangeData["email"], PDO::PARAM_STR);
      $stmt->bindParam(
        ":password_hash",
        $userChangeData["password_hash"],
        PDO::PARAM_STR
      );
      $stmt->bindParam(":id", $userChangeData["id"], PDO::PARAM_INT);
      $user = $stmt->execute();
      $stmt = null;
      return $user;
    } catch (\Throwable $th) {
      $errors = $this->conn->errorInfo();
      if ($errors) {
        return $errors;
      }
      dump($th);
    }
  }
  // PREPARE STMT DONE
  public function deleteUser(int $id): void
  {
    try {
      $stmt = $this->conn->prepare("DELETE FROM users WHERE id=:id LIMIT 1");
      $stmt->bindParam(":id", $id, PDO::PARAM_INT);
      $stmt->execute();
      $stmt = null;
    } catch (\Throwable $th) {
      throw $th;
    }
  }
  // PREPARE STMT DONE
  public function deleteFile(int $id): void
  {
    try {
      $stmt = $this->conn->prepare(
        "UPDATE blogs SET fileName=null, fileId=null WHERE id=:id LIMIT 1"
      );
      $stmt->bindParam(":id", $id, PDO::PARAM_INT);
      $stmt->execute();
      $stmt = null;
    } catch (\Throwable $th) {
      throw $th;
    }
  }

  // WHITE-LIST
  public function white_list(&$value, $allowed, $message)
  {
    if ($value === null) {
      return $allowed[0];
    }
    $key = array_search($value, $allowed, true);
    if ($key === false) {
      throw new Error($message);
    } else {
      return $value;
    }
  }
}
