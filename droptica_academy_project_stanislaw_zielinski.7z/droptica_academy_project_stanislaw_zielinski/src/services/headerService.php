<?php
session_start();
$email = $_SESSION["user"][0]["email"] ?? "Guest";
$name = $_SESSION["user"][0]["name"] ?? "Guest";
$userId = $_SESSION["user"][0]["id"] ?? "unknownId";
$password_hash = $_SESSION["user"][0]["password_hash"] ?? null;
$admin = $_SESSION["user"][0]["admin"] ?? null;
$userData =
  [
    "name" => $name ?? "Guest",
    "email" => $email ?? "Guest",
    "id" => $userId ?? "unknownId",
    "password_hash" => $password_hash ?? null,
    "admin" => $admin ?? null,
  ] ?? [];
?>
