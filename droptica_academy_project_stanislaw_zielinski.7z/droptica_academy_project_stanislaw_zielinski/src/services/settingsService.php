<?php
$is_invalid = false;
$data = [
  "is_invalid" => $is_invalid,
];

//   POST METHOD
if ($this->request->isPost()) {
  $newName = $this->request->postParam("newName");
  if ($newName === "") {
    $newName = $userData["name"];
  }
  $newEmail = $this->request->postParam("newEmail");
  if ($newEmail === "") {
    $newEmail = $userData["email"];
  }
  if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
    die("Valid email is required");
  }
  $newPassword = $this->request->postParam("newPassword");
  if (strlen($newPassword) < 8 && strlen($newPassword) > 0) {
    die("Password must be at least 8 characters long");
  }
  if (!preg_match("/[a-z]/i", $newPassword) && strlen($newPassword) > 0) {
    die("Password must contain at least one letter");
  }
  if (!preg_match("/[0-9]/", $newPassword) && strlen($newPassword) > 0) {
    die("Password must contain at least one number");
  }
  $newPasswordRepeat = $this->request->postParam("newPasswordRepeat");
  if ($newPassword !== $newPasswordRepeat) {
    die("Passwords must match");
  }
  $oldPassword = $this->request->postParam("oldPassword");
  if (password_verify($oldPassword, $userData["password_hash"])) {
    switch ($newPassword) {
      case "":
        $newUserData = [
          "id" => $userData["id"],
          "name" => $newName,
          "email" => $newEmail,
          "password_hash" => $userData["password_hash"],
          "admin" => $userData["admin"],
        ];
        $updateUserDataWithoutNewPassword = $this->updateUserDataWithoutNewPassword(
          $newUserData
        );
        break;
      default:
        $newUserData = [
          "id" => $userData["id"],
          "name" => $newName,
          "email" => $newEmail,
          "password_hash" => password_hash($newPassword, PASSWORD_DEFAULT),
          "admin" => $userData["admin"],
        ];
        $updateUserDataWithNewPassword = $this->updateUserDataWithNewPassword(
          $newUserData
        );

        break;
    }
    if (
      isset($updateUserDataWithoutNewPassword[1]) ||
      isset($updateUserDataWithNewPassword[1])
    ) {
      echo "Email already in use";
    } else {
      session_regenerate_id();
      $_SESSION["user"] = [$newUserData];
      header("Location:/?action=changeUserAccountDataSuccess");
    }
  } else {
    $is_invalid = true;
    $data = [
      "is_invalid" => $is_invalid,
    ];
  }
}
