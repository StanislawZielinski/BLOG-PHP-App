<?php

$phrase = $this->request->getParam("phrase");
$pagination = [
  "pageNumber" => (int) $this->request->getParam("pageNumber", 1),
  "pageSize" => (int) self::DEFAULT_LIMIT,
];
$sortOrder = $this->request->getParam("sortOrder", "desc");
$sortBy = $this->request->getParam("sortBy", "created");
if ($phrase) {
  $getData = $this->getUsersWithPhrase(
    $phrase,
    $pagination,
    $sortOrder,
    $sortBy
  );
  $countUsers = $this->database->countUsersWithPhrase($phrase);
} else {
  $getData = $this->getUsers($pagination, $sortOrder, $sortBy);
  $countUsers = $this->database->countAllUsers();
}
$data = [
  "pagination" => $pagination,
  "users" => $getData,
  "pages" => (int) ceil($countUsers / $pagination["pageSize"]),
  "totalUsers" => $countUsers,
  "sort" => [
    "by" => $sortBy,
    "sortOrder" => $sortOrder,
  ],
  "phrase" => $phrase,
];
?>
