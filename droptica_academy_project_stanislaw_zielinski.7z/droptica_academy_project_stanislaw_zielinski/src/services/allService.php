<?php
$pagination = [
  "pageNumber" => (int) $this->request->getParam("pageNumber", 1),
  "pageSize" => (int) self::DEFAULT_LIMIT,
];
$getData = $this->getAllPosts($pagination);
$numberOfAllPosts = $this->database->countAllPosts();
$data = [
  "pagination" => $pagination,
  "posts" => $getData,
  "pages" => (int) ceil($numberOfAllPosts / $pagination["pageSize"]),
  "totalPosts" => $numberOfAllPosts,
];
?>
