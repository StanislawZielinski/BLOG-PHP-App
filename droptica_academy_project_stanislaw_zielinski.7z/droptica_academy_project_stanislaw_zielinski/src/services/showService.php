<?php
$idFromUrl = $this->request->getParam("id");
$postId = (int) ($idFromUrl ?? null);
try {
  $data = $this->database->getPost($postId);
} catch (Throwable $e) {
  header("Location: /");
  exit();
}

try {
  $didUserVotedForThatPost = $this->didUserVotedForThatPost(
    (int) $data["id"],
    (int) $userData["id"]
  );
} catch (\Throwable $th) {
  throw $th;
}

try {
  $star = $this->request->postParam("star");
  if ($this->request->isPost()) {
    if (isset($star)) {
      $this->addStar($postId);
      $this->markAsCheckedInStarsDB($postId, $userData["id"]);
      header("Refresh:0");
    }
  }
} catch (\Throwable $th) {
  throw $th;
}
?>
