<?php
$success = "";
$unsuccess = "file deleting error";
try {
  if (isset($_POST["fileId"])) {
    $path = "files/" . $_POST["fileId"];

    // DELETE FROM FILES
    if (!unlink($path)) {
      $unsuccess = "delete process error: file does not exist!";
    } else {
      $success = "file deleted";
    }
  }
  // DELETE FROM DB
  $postId = $this->request->postParam("postId");
  $result = $this->database->deleteFile($postId);
  if ($result) {
    $success = "file deleted";
  } else {
    $unsuccess = "delete process error: file in DB does not exist!";
  }
} catch (\Throwable $th) {
  throw $th;
}
$data = [
  "success" => $success,
  "unsuccess" => $unsuccess,
];
