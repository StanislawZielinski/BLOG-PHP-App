<?php
$idFromUrl = $this->request->getParam("id");
$postId = (int) ($idFromUrl ?? null);
try {
  $data = $this->database->getPost($postId);
} catch (Throwable $e) {
  header("Location: /");
  exit();
}
if ($this->request->isPost()) {
  $id = (int) $this->request->postParam("id");
  $this->database->deletePost($id);
  header("Location:/?action=adminPosts");
  exit();
}
