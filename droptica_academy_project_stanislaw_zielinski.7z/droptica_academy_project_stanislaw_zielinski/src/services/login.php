<?php
$is_invalid = false;
$data = [
  "is_invalid" => $is_invalid,
];
if ($this->request->isPost()) {
  $email = $this->request->postParam("email");
  $user = $this->getUser($email);
  if ($user) {
    $data =
      [
        "user" => $user,
        "is_invalid" => $is_invalid,
      ] ?? [];
    $password_hash = $this->request->postParam("password");
    if (password_verify($password_hash, $user["password_hash"])) {
      $data =
        [
          "user" => $user,
          "is_invalid" => $is_invalid,
        ] ?? [];
      session_regenerate_id();
      $_SESSION["user"] = [$user];
      header("Location:/");
      exit();
    } else {
      $is_invalid = true;
      $data =
        [
          "user" => $user,
          "is_invalid" => $is_invalid,
        ] ?? [];
    }
  } else {
    $data = ["is_invalid" => "email does not exist"];
  }
}

?>
