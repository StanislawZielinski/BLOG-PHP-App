<?php
$pagination = [
  "pageNumber" => 1,
  "pageSize" => (int) self::DEFAULT_LIMIT,
];
$dataPromotedPosts = $this->getPromotedPosts($pagination);
$dataRecent = $this->getAllPosts($pagination);
$dataMostStars = $this->getTheMostPopularPosts($pagination);
$data = [
  "promoted" => $dataPromotedPosts,
  "recent" => $dataRecent,
  "mostStars" => $dataMostStars,
]; ?>
