<?php
$file = $_FILES["file"];
$fileNewName = null;
$fileName = $file["name"];
$fileSize = $file["size"];
$fileTmpName = $file["tmp_name"];
$fileError = $file["error"];
if (empty($fileError)) {
  // extension
  $fileExt = explode(".", $fileName);
  $fileActualExt = strtolower(end($fileExt));
  $allowedExt = ["jpg", "jpeg", "png", "gif", "pdf", "txt", "svg"];

  if (in_array($fileActualExt, $allowedExt)) {
    if ($fileSize < 1000000) {
      $fileNewName = uniqid("", true) . "." . $fileActualExt;
      $fileDestination = "files/" . $fileNewName;
      move_uploaded_file($fileTmpName, $fileDestination);
    } else {
      $isFileOk = false;
      $errorFileMessage = "File size is too large";
    }
  } else {
    $isFileOk = false;
    $errorFileMessage = "Invalid file type";
  }
}
