<?php
$idFromUrl = $this->request->getParam("id");
$userId = (int) ($idFromUrl ?? null);
$is_user_invalid = false;

if ($this->request->isGet()) {
  try {
    $getData = $this->database->getUserById($userId);
    $data = [
      "user" => $getData,
      "is_user_invalid" => $is_user_invalid,
    ];
  } catch (Throwable $e) {
    header("Location: /");
    exit();
  }
}

// EDITING USER BY ADMIN
if ($this->request->hasPost()) {
  $id = $this->request->postParam("id");
  $getUserData = $this->database->getUserById($userId);
  $name = $this->request->postParam("name");
  if (empty($name)) {
    die("Name is required");
  }
  $email = $this->request->postParam("email");
  if ($email === "") {
    $email = $getUserData["email"];
  }
  if ($email !== $getUserData["email"]) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      die("Valid email is required");
    }
  }
  $password = $this->request->postParam("password");
  if (strlen($password) < 8 && strlen($password) > 0) {
    die("Password must be at least 8 characters long");
  }
  if (!preg_match("/[a-z]/i", $password) && strlen($password) > 0) {
    die("Password must contain at least one letter");
  }
  if (!preg_match("/[0-9]/", $password) && strlen($password) > 0) {
    die("Password must contain at least one number");
  }
  $passwordRepeat = $this->request->postParam("passwordRepeat");
  if ($password !== $passwordRepeat) {
    die("Passwords must match");
  }
  $admin = $this->request->postParam("admin");

  try {
    switch ($password) {
      case "":
        $newUserData = [
          "id" => $id,
          "name" => $name,
          "email" => $email,
          "admin" => $admin,
          "password_hash" => $getUserData["password_hash"],
        ];
        $adminEditUserDataWithoutNewPassword = $this->adminEditUserDataWithoutNewPassword(
          $newUserData
        );
        break;
      default:
        $newUserData = [
          "id" => $id,
          "name" => $name,
          "email" => $email,
          "admin" => $admin,
          "password_hash" => password_hash($password, PASSWORD_DEFAULT),
        ];
        $adminEditUserDataWithNewPassword = $this->adminEditUserDataWithNewPassword(
          $newUserData
        );
        break;
    }
    if (
      isset($adminEditUserDataWithoutNewPassword[1]) ||
      isset($adminEditUserDataWithNewPassword[1])
    ) {
      $id = $this->request->postParam("id");
      $getData = $this->database->getUserById($id);
      $is_user_invalid = true;
      $data = [
        "user" => $getData,
        "is_user_invalid" => $is_user_invalid,
      ];
    } else {
      header("Location:/?action=adminUsers");
    }
  } catch (\Throwable $th) {
    $is_invalid = true;
    $data = [
      "is_invalid" => $is_invalid,
    ];
    throw $th;
  }
}
