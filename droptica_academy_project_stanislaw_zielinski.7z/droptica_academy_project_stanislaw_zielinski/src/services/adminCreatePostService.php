<?php
$availabeCategories = $this->database->getCategories() ?? [];
$is_post_invalid = false;
$isFileOk = true;
$errorFileMessage = null;
$data = [
  "availableCategories" => $availabeCategories,
  "is_post_invalid" => $is_post_invalid,
];

// ADDING NEW POST
if ($this->request->hasPost()) {
  include_once "fileUpload.php";
  $title = $this->request->postParam("title");
  $description = $this->request->postParam("description");
  $author = $this->request->postParam("author");
  $category = $this->request->postParam("category");
  $image = $this->request->postParam("image");
  $promoted = $this->request->postParam("promoted");

  // UNCOMMENT THIS WHEN FILE LOGIC IS COMPLETE!!!
  if ($title && $author && $isFileOk) {
    $postData = [
      "title" => $title,
      "description" => $description,
      "author" => $author,
      "category" => $category,
      "image" => $image,
      "promoted" => $promoted,
      "fileName" => $fileName,
      "fileId" => $fileNewName,
    ];
    $this->createNewPost($postData);
    header("Location:/?action=adminPosts");
    exit();
  } else {
    $is_post_invalid = true;
    $data =
      [
        "is_post_invalid" => $is_post_invalid,
        "availableCategories" => $availabeCategories,
        "errorFileMessage" => $errorFileMessage,
      ] ?? [];
  }
}
