<?php

if (!empty($_POST)) {
  $name = $this->request->postParam("name");
  if (empty($name)) {
    die("Name is required");
  }
  $email = $this->request->postParam("email");
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Valid email is required");
  }
  $password = $this->request->postParam("password");
  if (strlen($password) < 8) {
    die("Password must be at least 8 characters long");
  }
  if (!preg_match("/[a-z]/i", $password)) {
    die("Password must contain at least one letter");
  }
  if (!preg_match("/[0-9]/", $password)) {
    die("Password must contain at least one number");
  }
  $passwordRepeat = $this->request->postParam("passwordRepeat");
  if ($password !== $passwordRepeat) {
    die("Passwords must match");
  }

  $password_hash = password_hash($password, PASSWORD_DEFAULT);
  $data = [
    "name" => $name,
    "email" => $email,
    "password_hash" => $password_hash,
  ];
  try {
    $createUser = $this->createUser($data);
    header("Location:/?action=signupSuccess");
    exit();
  } catch (\Throwable $th) {
    if (is_array($createUser)) {
      if (isset($createUser[1])) {
        echo $createUser[2];
      }
    }
    throw $th;
  }
} ?>
