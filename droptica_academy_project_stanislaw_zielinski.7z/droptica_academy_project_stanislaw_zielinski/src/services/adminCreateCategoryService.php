<?php
$invalid = false;
$existingCategories = $this->database->getCategories();

$existingCategory = array_map("callback", $existingCategories);
function callback(array $category)
{
  return $category["category"];
}
$checkIfCategoryIsAssigned = $this->database->checkIfCategoryIsAssigned();

if ($this->request->hasPost()) {
  try {
    $newCategory = $this->request->postParam("newCategory");
    $idDeleteCategory = $this->request->postParam("id");
    if ($newCategory) {
      if (
        in_array(strtolower($newCategory), $existingCategory) ||
        $newCategory === ""
      ) {
        $invalid = true;
      } else {
        $this->createNewCategory($newCategory);
        header("refresh:0");
      }
    }
    if ($idDeleteCategory) {
      $this->database->deleteCategory($idDeleteCategory);
      header("refresh:0");
    }
  } catch (\Throwable $th) {
    throw $th;
  }
}

$data = [
  "existingCategories" => $existingCategories,
  "invalid" => $invalid,
  "checkIfCategoryIsAssigned" => $checkIfCategoryIsAssigned,
];
