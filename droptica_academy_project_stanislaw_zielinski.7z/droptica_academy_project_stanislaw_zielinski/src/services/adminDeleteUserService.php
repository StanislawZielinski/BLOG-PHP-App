<?php

if ($this->request->isGet()) {
  try {
    $idFromUrl = $this->request->getParam("id");
    $userId = (int) ($idFromUrl ?? null);
    $data = $this->database->getUserById($userId);
  } catch (Throwable $e) {
    header("Location: /");
    exit();
  }
}

// DELETE USER
if ($this->request->isPost()) {
  $id = (int) $this->request->postParam("id");
  $this->database->deleteUser($id);
  header("Location:/?action=adminUsers");
  exit();
}
