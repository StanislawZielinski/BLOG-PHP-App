<?php
$is_post_invalid = false;
$idFromUrl = $this->request->getParam("id");
$postId = (int) ($idFromUrl ?? null);
$availabeCategories = $this->database->getCategories() ?? [];
if ($this->request->isGet()) {
  try {
    $getData = $this->database->getPost($postId);
    $data = [
      "post" => $getData,
      "availableCategories" => $availabeCategories,
      "is_post_invalid" => $is_post_invalid,
    ];
  } catch (Throwable $e) {
    header("Location: /");
    exit();
  }
}

// EDITING POST
if ($this->request->hasPost()) {
  $id = $this->request->postParam("id");
  $title = $this->request->postParam("title");
  $description = $this->request->postParam("description");
  $author = $this->request->postParam("author");
  $category = $this->request->postParam("category");
  $image = $this->request->postParam("image");
  $promoted = $this->request->postParam("promoted");
  if ($title && $author) {
    // $is_post_invalid = false;
    $postData = [
      "id" => $id,
      "title" => $title,
      "description" => $description,
      "author" => $author,
      "category" => $category,
      "image" => $image,
      "promoted" => $promoted,
    ];

    $this->editPost($postData);
    header("Location:/?action=adminPosts");
    exit();
  } else {
    $is_post_invalid = true;
    $data =
      [
        "is_post_invalid" => $is_post_invalid,
        "availableCategories" => $availabeCategories,
      ] ?? [];
  }
}
