<?php
$pagination = [
  "pageNumber" => (int) $this->request->getParam("pageNumber", 1),
  "pageSize" => (int) self::DEFAULT_LIMIT,
];
$getData = $this->getPosts($page, $pagination);
$numberOfPostsInCategory = $this->database->countInCategory($page);
$data = [
  "pagination" => $pagination,
  "posts" => $getData,
  "pages" => (int) ceil($numberOfPostsInCategory / $pagination["pageSize"]),
  "totalPosts" => $numberOfPostsInCategory,
];
?>
