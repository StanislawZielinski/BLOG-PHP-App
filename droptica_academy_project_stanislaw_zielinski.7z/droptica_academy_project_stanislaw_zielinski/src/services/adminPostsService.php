<?php
if (!$admin) {
  die("no permission");
}
$availabeCategories = $this->database->getCategories();
$phrase = $this->request->getParam("phrase");
$pagination = [
  "pageNumber" => (int) $this->request->getParam("pageNumber", 1),
  "pageSize" => (int) self::DEFAULT_LIMIT,
];
$sortOrder = $this->request->getParam("sortOrder", "desc");
$sortBy = $this->request->getParam("sortBy", "created");
$category = $this->request->getParam("category", "category");
if ($phrase) {
  $getData = $this->adminGetPostsWithPhrase(
    $phrase,
    $pagination,
    $sortOrder,
    $sortBy,
    $category
  );
  $countPosts = $this->database->countAdminGetPostsWithPhrase(
    $phrase,
    $category
  );
} else {
  $getData = $this->adminGetPosts($pagination, $sortOrder, $sortBy, $category);
  $countPosts = $this->database->countAdminInCategory($category);
}
$numberOfAllPosts = $this->database->countAllPosts();
$data = [
  "pagination" => $pagination,
  "posts" => $getData,
  "pages" => (int) ceil($countPosts / $pagination["pageSize"]),
  "totalPosts" => $countPosts,
  "sort" => [
    "by" => $sortBy,
    "sortOrder" => $sortOrder,
  ],
  "availableCategories" => $availabeCategories,
  "phrase" => $phrase,
  "category" => $category,
];
?>
