const validationNewPost = new JustValidate("#newPost");
validationNewPost
  .addField("#title", [
    { rule: "required" },
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 20,
    },
  ])
  .addField("#author", [
    { rule: "required" },
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 20,
    },
  ])
  .addField("#file", [
    {
      rule: "files",
      value: {
        files: {
          extensions: ["jpeg", "jpg", "png", "pdf", "txt", "gif", "svg"],
          maxSize: 1000000,
          minSize: 1000,
          types: [
            "image/jpeg",
            "image/jpg",
            "image/png",
            "application/pdf",
            "text/plain",
            "image/gif",
            "image/svg+xml",
          ],
        },
      },
    },
  ])
  .onSuccess((event) => {
    document.getElementById("newPost").submit();
  });
