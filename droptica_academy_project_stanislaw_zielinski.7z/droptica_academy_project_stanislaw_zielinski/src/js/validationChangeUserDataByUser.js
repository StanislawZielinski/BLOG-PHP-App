const validationChangeUserDataByUser = new JustValidate(
  "#changeUserDataByUser"
);
validationChangeUserDataByUser
  .addField("#newName", [
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 15,
    },
    {
      rule: "customRegexp",
      value: /[a-z]/gi,
    },
  ])
  .addField("#newEmail", [
    { rule: "email" },
    {
      validator: (value) => () => {
        return fetch("emailValidation.php?email=" + encodeURIComponent(value))
          .then(function (response) {
            return response.json();
          })
          .then(function (json) {
            return json.available;
          });
      },
      errorMessage: "Email already in Database",
    },
  ])
  .addField("#newPassword", [{ rule: "password" }])
  .addField("#newPasswordRepeat", [
    {
      validator: (value, fields) => {
        return value === fields["#newPassword"].elem.value;
      },
      errorMessage: "Passwords should match",
    },
  ])
  .onSuccess((event) => {
    document.getElementById("changeUserDataByUser").submit();
  });
