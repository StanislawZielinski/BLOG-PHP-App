let firstChildOfCarousel = document.body
  .querySelector(".carousel-item")
  ?.classList.add("active");
