const validationCategory = new JustValidate("#createCategory");
validationCategory
  .addField("#newCategory", [
    { rule: "required" },
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 15,
    },
    {
      rule: "customRegexp",
      value: /[a-z]/gi,
    },
  ])
  .onSuccess((event) => {
    document.getElementById("createCategory").submit();
  });
