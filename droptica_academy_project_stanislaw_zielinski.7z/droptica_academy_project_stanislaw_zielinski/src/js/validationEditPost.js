const validationNewPost = new JustValidate("#newPost");
validationNewPost
  .addField("#title", [
    { rule: "required" },
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 20,
    },
  ])
  .addField("#author", [
    { rule: "required" },
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 20,
    },
  ])
  .onSuccess((event) => {
    document.getElementById("newPost").submit();
  });
