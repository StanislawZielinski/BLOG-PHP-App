const validationChangeUserDataByAdmin = new JustValidate("#editUser");
validationChangeUserDataByAdmin
  .addField("#name", [
    {
      rule: "minLength",
      value: 3,
    },
    {
      rule: "maxLength",
      value: 15,
    },
    {
      rule: "customRegexp",
      value: /[a-z]/gi,
    },
  ])
  .addField("#email", [
    { rule: "email" },
    {
      validator: (value) => () => {
        return fetch("emailValidation.php?email=" + encodeURIComponent(value))
          .then(function (response) {
            return response.json();
          })
          .then(function (json) {
            return json.available;
          });
      },
      errorMessage: "Email already in Database",
    },
  ])
  .addField("#password", [{ rule: "password" }])
  .addField("#passwordRepeat", [
    {
      validator: (value, fields) => {
        return value === fields["#password"].elem.value;
      },
      errorMessage: "Passwords should match",
    },
  ])
  .onSuccess((event) => {
    document.getElementById("editUser").submit();
  });
