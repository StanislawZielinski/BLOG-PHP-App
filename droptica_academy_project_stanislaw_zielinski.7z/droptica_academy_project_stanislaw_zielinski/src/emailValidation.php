<?php
declare(strict_types=1);
namespace App;
require_once "./Database.php";
$configuration = require_once "./config/config.php";
class EmailValidation
{
  private $database;
  private static array $configuration = [];

  public static function initConfiguration(array $configuration): void
  {
    self::$configuration = $configuration;
  }
  public function __construct()
  {
    $this->database = new Database(self::$configuration["db"]);
  }
  public function checkIfEmailIsAvaliable($emailFromUrl)
  {
    $data = $this->database->checkIfEmailIsAvaliable($emailFromUrl);
    return $data;
  }
}
try {
  if (isset($_GET["email"]) or isset($_GET["newEmail"])) {
    ($emailFromUrl = $_GET["email"]) or $_GET["newName"];
    EmailValidation::initConfiguration($configuration);
    $emailValidate = new EmailValidation();
    $getData = $emailValidate->checkIfEmailIsAvaliable($emailFromUrl);
    $is_avalable = $getData === 0;
    header("Content-Type:application/json");
    echo json_encode(["available" => $is_avalable]);
  }
} catch (\Throwable $th) {
  throw $th;
}
?>
