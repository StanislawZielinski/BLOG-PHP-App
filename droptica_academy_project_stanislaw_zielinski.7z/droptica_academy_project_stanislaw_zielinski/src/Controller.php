<?php
declare(strict_types=1);
namespace App;

use Throwable;
class Controller
{
  private Request $request;
  private View $view;
  private $database;
  protected const DEFAULT_ACTION = "main";
  private const DEFAULT_LIMIT = 10;
  private const DEFAULT_PAGE = 1;
  private static array $configuration = [];
  public static function initConfiguration(array $configuration): void
  {
    self::$configuration = $configuration;
  }
  private array $availableAction = [
    "war",
    "sport",
    "politics",
    "news",
    "celebrities",
    "all",
    "info",
    "author",
    "login",
    "signup",
    "signupSuccess",
    "changeUserAccountDataSuccess",
    "show",
    "main",
    "popular",
    "logout",
    "settings",
    "adminPosts",
    "adminCreatePost",
    "adminDeletePost",
    "adminCreateCategory",
    "editPost",
    "adminUsers",
    "editUser",
    "adminDeleteUser",
    "adminDeleteFile",
  ];

  public function __construct($request)
  {
    $this->request = $request;
    $this->database = new Database(self::$configuration["db"]);
    $this->view = new View();
  }

  private function action(): string
  {
    return $this->request->getParam("action") ?? self::DEFAULT_ACTION;
  }

  public function run(): void
  {
    $action = htmlspecialchars($this->action());

    if (in_array($action, $this->availableAction)) {
      $action = $action;
    } else {
      $action = self::DEFAULT_ACTION;
    }
    include_once "./services/headerService.php";
    switch ($action) {
      case "signup":
        $page = "signup";
        include_once "./services/signup.php";
        break;
      case "signupSuccess":
        $page = "signupSuccess";
        break;
      case "changeUserAccountDataSuccess":
        $page = "changeUserAccountDataSuccess";
        break;
      case "login":
        $page = "login";
        include_once "./services/login.php";
        break;
      case "logout":
        $page = "logout";
        include_once "./services/logout.php";
        break;
      case "settings":
        $page = "settings";
        include_once "./services/settingsService.php";
        break;
      case "info":
        $page = "info";
        break;
      case "author":
        $page = "author";
        break;
      case "politics":
        $page = "politics";
        include_once "./services/categoryService.php";
        break;
      case "war":
        $page = "war";
        include_once "./services/categoryService.php";
        break;
      case "news":
        $page = "news";
        include_once "./services/categoryService.php";
        break;
      case "celebrities":
        $page = "celebrities";
        include_once "./services/categoryService.php";
        break;
      case "sport":
        $page = "sport";
        include_once "./services/categoryService.php";
        break;
      case "popular":
        $page = "popular";
        include_once "./services/popularService.php";
        break;
      case "all":
        $page = "all";
        include_once "./services/allService.php";
        break;
      case "adminPosts":
        $page = "adminPosts";
        include_once "./services/adminPostsService.php";
        break;
      case "editPost":
        $page = "editPost";
        include_once "./services/adminEditPostService.php";
        break;
      case "adminCreatePost":
        $page = "adminCreatePost";
        include_once "./services/adminCreatePostService.php";
        break;
      case "adminDeletePost":
        $page = "adminDeletePost";
        include_once "./services/adminDeletePostService.php";
        break;
      case "adminCreateCategory":
        $page = "adminCreateCategory";
        include_once "./services/adminCreateCategoryService.php";
        break;
      case "adminUsers":
        $page = "adminUsers";
        include_once "./services/adminUsersService.php";
        break;
      case "editUser":
        $page = "editUser";
        include_once "./services/editUserService.php";
        break;
      case "adminDeleteUser":
        $page = "adminDeleteUser";
        include_once "./services/adminDeleteUserService.php";
        break;
      case "adminDeleteFile":
        $page = "adminDeleteFile";
        include_once "./services/adminDeleteFileService.php";
        break;
      case "show":
        $page = "show";
        include_once "./services/showService.php";
        break;
      default:
        $page = "main";
        include_once "./services/defaultService.php";
        break;
    }
    try {
      $this->view->render(
        $page,
        $data ?? [],
        $userData ?? [],
        $didUserVotedForThatPost ?? null
      );
    } catch (\Throwable $e) {
      $this->view->render(
        "error",
        ["message" => $e->getMessage()],
        $userData,
        $didUserVotedForThatPost ?? null
      );
      throw $e;
    }
  }

  public function getPosts($category, $pagination)
  {
    $data = $this->database->getPosts($category, $pagination);
    return $data;
  }
  public function getAllPosts($pagination)
  {
    $data = $this->database->getAllPosts($pagination);
    return $data;
  }
  public function getTheMostPopularPosts($limit = self::DEFAULT_LIMIT)
  {
    $data = $this->database->getTheMostPopularPosts($limit);
    return $data;
  }
  public function getPromotedPosts($limit = self::DEFAULT_LIMIT)
  {
    $data = $this->database->getPromotedPosts($limit);
    return $data;
  }

  // USERS
  public function createUser($data)
  {
    $data = $this->database->createUser($data);
    return $data;
  }
  public function getUser($data)
  {
    $data = $this->database->getUser($data);
    return $data;
  }
  public function updateUserDataWithoutNewPassword($newUserData)
  {
    $data = $this->database->updateUserDataWithoutNewPassword($newUserData);
    return $data;
  }
  public function updateUserDataWithNewPassword($newUserData)
  {
    $data = $this->database->updateUserDataWithNewPassword($newUserData);
    return $data;
  }
  public function addStar($id): void
  {
    $this->database->addStar($id);
  }
  // STARS - USER & POST
  public function markAsCheckedInStarsDB($postId, $userId)
  {
    $this->database->markAsCheckedInStarsDB($postId, $userId);
  }
  public function didUserVotedForThatPost($postId, $userId)
  {
    $data = $this->database->didUserVotedForThatPost($postId, $userId);
    return $data;
  }
  // ADMIN
  public function adminGetPosts($pagination, $sortOrder, $sortBy, $category)
  {
    $data = $this->database->adminGetPosts(
      $pagination,
      $sortOrder,
      $sortBy,
      $category
    );
    return $data;
  }
  public function adminGetPostsWithPhrase(
    $phrase,
    $pagination,
    $sortOrder,
    $sortBy,
    $category
  ) {
    $data = $this->database->adminGetPostsWithPhrase(
      $phrase,
      $pagination,
      $sortOrder,
      $sortBy,
      $category
    );
    return $data;
  }
  public function createNewCategory($newCategory)
  {
    $data = $this->database->createNewCategory($newCategory);
    return $data;
  }
  public function createNewPost($postData)
  {
    $data = $this->database->createNewPost($postData);
    return $data;
  }
  public function editPost($postData)
  {
    $result = $this->database->editPost($postData);
    return $result;
  }

  public function getUsersWithPhrase($phrase, $pagination, $sortOrder, $sortBy)
  {
    $data = $this->database->getUsersWithPhrase(
      $phrase,
      $pagination,
      $sortOrder,
      $sortBy
    );
    return $data;
  }
  public function getUsers($pagination, $sortOrder, $sortBy)
  {
    $data = $this->database->getUsers($pagination, $sortOrder, $sortBy);
    return $data;
  }
  public function adminEditUserDataWithoutNewPassword($userChangeData)
  {
    $result = $this->database->adminEditUserDataWithoutNewPassword(
      $userChangeData
    );
    return $result;
  }
  public function adminEditUserDataWithNewPassword($userChangeData)
  {
    $result = $this->database->adminEditUserDataWithNewPassword(
      $userChangeData
    );
    return $result;
  }
}

?>
