#Droptica_final_project

The project is ready to start with docker-compose.
Change your directory and run: docker-compose up -d.
In order to start please follow 2 steps:

1. CREATE A DATABASE NAMED "blogs" AND IMPORT THE SQL FILE AND RUN.
2. CREATE A USER: "user_blogs", PASSWORD: "mojehaslo" AND GIVE PRIVILLEGES.

Without the database the project won't run.
Database file is inside "databasefile" folder

admin:
email: admin@admin.pl
password: admin123
